begin;
alter table public.winter_gifts add column photo text not null default ''
  check (photo='' or (char_length(photo)<=90000 and photo ~ '^data:image/jpeg;base64,[A-Za-z0-9+/]+={0,2}$'));

create or replace function public.winter_add_gift(payload jsonb) returns void
language plpgsql security definer set search_path='' as $$
declare ornament_id uuid;
begin
  if not exists(select 1 from public.winter_owner) then raise exception 'Owner must be configured'; end if;
  insert into public.winter_ornaments(color) values(payload->>'color') returning id into ornament_id;
  insert into public.winter_gifts(id,sender,message,song,url,photo)
  values(ornament_id,payload->>'sender',payload->>'message',payload->>'song',payload->>'url',coalesce(payload->>'photo',''));
end;
$$;
commit;
