begin;
alter table public.winter_ornaments
  drop constraint winter_ornaments_shape_check,
  add column outline jsonb,
  add constraint winter_ornaments_shape_check
    check (shape in ('sphere','drop','star','flake','present','reindeer','custom')),
  add constraint winter_ornaments_outline_check
    check (case when shape='custom' then
      case when jsonb_typeof(outline)='array' then jsonb_array_length(outline) between 4 and 120 else false end
    else outline is null end);

create or replace function public.winter_add_gift(payload jsonb) returns void
language plpgsql security definer set search_path='' as $$
declare ornament_id uuid;
begin
  if not exists(select 1 from public.winter_owner) then raise exception 'Owner must be configured'; end if;
  insert into public.winter_ornaments(color,shape,scene_x,scene_y,outline)
  values(payload->>'color',coalesce(payload->>'shape','sphere'),(payload->>'scene_x')::double precision,(payload->>'scene_y')::double precision,nullif(payload->'outline','null'::jsonb)) returning id into ornament_id;
  insert into public.winter_gifts(id,sender,message,song,url,photo)
  values(ornament_id,payload->>'sender',payload->>'message',payload->>'song',payload->>'url',coalesce(payload->>'photo',''));
end;
$$;
commit;
