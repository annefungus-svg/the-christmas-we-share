begin;
create table public.winter_owner (
  singleton boolean primary key default true check(singleton),
  user_id uuid not null references auth.users(id) on delete cascade
);
create table public.winter_ornaments (
  id uuid primary key default gen_random_uuid(),
  color text not null check (color in ('gold','ice','rose','mint','silver')),
  created_at timestamptz not null default now()
);
create table public.winter_gifts (
  id uuid primary key references public.winter_ornaments(id) on delete cascade,
  sender text not null check (char_length(sender)<=40),
  message text not null check (char_length(message) between 1 and 600),
  song text not null check (char_length(song)<=120),
  url text not null check (url='' or (url like 'https://%' and char_length(url)<=700)),
  favorite boolean not null default false,
  created_at timestamptz not null default now(),
  check(song<>'' or url<>'')
);
create index winter_ornaments_latest on public.winter_ornaments(created_at desc,id);
create index winter_gifts_latest on public.winter_gifts(created_at desc,id);

create table public.winter_rates (
  bucket text not null,
  window_id bigint not null,
  hits integer not null,
  primary key(bucket,window_id)
);
create index winter_rates_expiry on public.winter_rates(window_id);
alter table public.winter_owner enable row level security;
alter table public.winter_gifts enable row level security;
alter table public.winter_ornaments enable row level security;
alter table public.winter_rates enable row level security;
revoke all on public.winter_owner,public.winter_gifts,public.winter_ornaments,public.winter_rates from public,anon,authenticated,service_role;
grant select on public.winter_ornaments to anon,authenticated;
grant delete on public.winter_ornaments to authenticated;
grant select,update(favorite) on public.winter_gifts to authenticated;

create function public.winter_is_owner() returns boolean
language sql stable security definer set search_path='' as $$
  select exists (select 1 from public.winter_owner where user_id=(select auth.uid()));
$$;
revoke all on function public.winter_is_owner() from public,anon,authenticated,service_role;
grant execute on function public.winter_is_owner() to authenticated;
create policy winter_public on public.winter_ornaments for select to anon,authenticated using(true);
create policy winter_remove on public.winter_ornaments for delete to authenticated using ((select public.winter_is_owner()));
create policy winter_owner_read on public.winter_gifts for select to authenticated using ((select public.winter_is_owner()));
create policy winter_owner_save on public.winter_gifts for update to authenticated using ((select public.winter_is_owner())) with check ((select public.winter_is_owner()));

create function public.winter_add_gift(payload jsonb) returns void
language plpgsql security definer set search_path='' as $$
declare ornament_id uuid;
begin
  if not exists(select 1 from public.winter_owner) then raise exception 'Owner must be configured'; end if;
  insert into public.winter_ornaments(color) values(payload->>'color') returning id into ornament_id;
  insert into public.winter_gifts(id,sender,message,song,url)
  values(ornament_id,payload->>'sender',payload->>'message',payload->>'song',payload->>'url');
end;
$$;
create function public.winter_take_rate(bucket text, action text) returns boolean
language plpgsql security definer set search_path='' as $$
declare current_window bigint := floor(extract(epoch from now())/600);
allowed integer := case action when 'gift' then 5 when 'login' then 8 else 0 end;
updated_hits integer;
begin
  if allowed=0 or bucket !~ '^[0-9a-f]{64}$' then return false; end if;
  insert into public.winter_rates as limits values(bucket,current_window,1)
  on conflict on constraint winter_rates_pkey do update set hits=limits.hits+1
    where limits.hits<allowed
  returning hits into updated_hits;
  delete from public.winter_rates where window_id < current_window-144;
  return updated_hits is not null;
end;
$$;
revoke all on function public.winter_add_gift(jsonb),public.winter_take_rate(text,text) from public,anon,authenticated,service_role;
grant execute on function public.winter_add_gift(jsonb),public.winter_take_rate(text,text) to service_role;
commit;
