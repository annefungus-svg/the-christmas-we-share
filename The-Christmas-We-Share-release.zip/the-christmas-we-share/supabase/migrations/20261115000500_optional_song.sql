begin;
alter table public.winter_gifts drop constraint winter_gifts_check;
commit;
