begin;
alter table public.winter_ornaments
  add column shape text not null default 'sphere' check (shape in ('sphere','drop','star','flake')),
  add column scene_x double precision,
  add column scene_y double precision,
  add constraint winter_placement check (
    (scene_x is null and scene_y is null)
    or (scene_x is not null and scene_y is not null and scene_x between 0 and 1 and scene_y between 0 and 1)
  );

create or replace function public.winter_add_gift(payload jsonb) returns void
language plpgsql security definer set search_path='' as $$
declare ornament_id uuid;
begin
  if not exists(select 1 from public.winter_owner) then raise exception 'Owner must be configured'; end if;
  insert into public.winter_ornaments(color,shape,scene_x,scene_y)
  values(payload->>'color',coalesce(payload->>'shape','sphere'),(payload->>'scene_x')::double precision,(payload->>'scene_y')::double precision) returning id into ornament_id;
  insert into public.winter_gifts(id,sender,message,song,url,photo)
  values(ornament_id,payload->>'sender',payload->>'message',payload->>'song',payload->>'url',coalesce(payload->>'photo',''));
end;
$$;
commit;
