begin;
create table public.winter_trees (
  slug text primary key check (slug ~ '^[a-z][a-z0-9_-]{2,23}$'),
  owner_id uuid not null unique references auth.users(id) on delete cascade
);
alter table public.winter_trees enable row level security;
revoke all on public.winter_trees from public,anon,authenticated,service_role;
grant select(slug) on public.winter_trees to anon,authenticated;
create policy winter_tree_public on public.winter_trees for select to anon,authenticated using(true);

alter table public.winter_ornaments
  add column tree_slug text references public.winter_trees(slug) on delete cascade;
create index winter_tree_feed on public.winter_ornaments(tree_slug,created_at desc,id);

create function public.winter_can_manage(tree text) returns boolean
language sql stable security definer set search_path='' as $$
  select case when tree is null then exists (
    select 1 from public.winter_owner where user_id=(select auth.uid())
  ) else exists (
    select 1 from public.winter_trees where slug=tree and owner_id=(select auth.uid())
  ) end;
$$;
revoke all on function public.winter_can_manage(text) from public,anon,authenticated,service_role;
grant execute on function public.winter_can_manage(text) to authenticated;
drop policy winter_remove on public.winter_ornaments;
drop policy winter_owner_read on public.winter_gifts;
drop policy winter_owner_save on public.winter_gifts;
create policy winter_remove on public.winter_ornaments for delete to authenticated
  using (public.winter_can_manage(tree_slug));
create policy winter_owner_read on public.winter_gifts for select to authenticated using (
  exists(select 1 from public.winter_ornaments as ornament
    where ornament.id=winter_gifts.id and public.winter_can_manage(ornament.tree_slug))
);
create policy winter_owner_save on public.winter_gifts for update to authenticated
  using (exists(select 1 from public.winter_ornaments as ornament
    where ornament.id=winter_gifts.id and public.winter_can_manage(ornament.tree_slug)));

create function public.winter_register_tree() returns trigger
language plpgsql security definer set search_path='' as $$
declare username text := new.raw_app_meta_data->>'winter_username';
begin
  if username is not null then
    insert into public.winter_trees(slug,owner_id) values(username,new.id);
  end if;
  return new;
end;
$$;
revoke all on function public.winter_register_tree() from public,anon,authenticated,service_role;
create trigger winter_register_tree after insert on auth.users
  for each row execute function public.winter_register_tree();

create or replace function public.winter_add_gift(payload jsonb) returns void
language plpgsql security definer set search_path='' as $$
declare ornament_id uuid;
begin
  if payload->>'tree_slug' is null and not exists(select 1 from public.winter_owner)
    then raise exception 'Owner must be configured'; end if;
  insert into public.winter_ornaments(color,shape,scene_x,scene_y,outline,tree_slug)
  values(payload->>'color',coalesce(payload->>'shape','sphere'),(payload->>'scene_x')::double precision,
    (payload->>'scene_y')::double precision,nullif(payload->'outline','null'::jsonb),payload->>'tree_slug')
  returning id into ornament_id;
  insert into public.winter_gifts(id,sender,message,song,url,photo)
  values(ornament_id,payload->>'sender',payload->>'message',payload->>'song',payload->>'url',coalesce(payload->>'photo',''));
end;
$$;

create or replace function public.winter_take_rate(bucket text, action text) returns boolean
language plpgsql security definer set search_path='' as $$
declare current_window bigint := floor(extract(epoch from now())/600);
allowed integer := case action when 'gift' then 5 when 'login' then 8 when 'signup' then 3 else 0 end;
updated_hits integer;
begin
  if allowed=0 or bucket !~ '^[0-9a-f]{64}$' then return false; end if;
  insert into public.winter_rates as limits values(bucket,current_window,1)
  on conflict on constraint winter_rates_pkey do update set hits=limits.hits+1
    where limits.hits<allowed returning hits into updated_hits;
  delete from public.winter_rates where window_id < current_window-144;
  return updated_hits is not null;
end;
$$;
commit;
