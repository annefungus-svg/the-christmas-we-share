begin;

alter table public.winter_ornaments
  add column scene_angle double precision
  check (scene_angle is null or (scene_angle >= 0 and scene_angle < 2*pi() and scene_x is not null and scene_y is not null));

create or replace function public.winter_add_gift(payload jsonb) returns void
language plpgsql security definer set search_path='' as $$
declare ornament_id uuid;
begin
  if payload->>'tree_slug' is null and not exists(select 1 from public.winter_owner)
    then raise exception 'Owner must be configured'; end if;
  insert into public.winter_ornaments(color,shape,scene_x,scene_y,outline,tree_slug,scene_angle)
  values(payload->>'color',coalesce(payload->>'shape','sphere'),(payload->>'scene_x')::double precision,
    (payload->>'scene_y')::double precision,nullif(payload->'outline','null'::jsonb),payload->>'tree_slug',(payload->>'scene_angle')::double precision)
  returning id into ornament_id;
  insert into public.winter_gifts(id,sender,message,song,url,photo)
  values(ornament_id,payload->>'sender',payload->>'message',payload->>'song',payload->>'url',coalesce(payload->>'photo',''));
end;
$$;

commit;
