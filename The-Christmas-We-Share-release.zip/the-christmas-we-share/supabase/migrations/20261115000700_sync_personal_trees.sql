begin;
create or replace function public.winter_register_tree() returns trigger
language plpgsql security definer set search_path='' as $$
declare username text := new.raw_app_meta_data->>'winter_username';
begin
  if username is not null then
    insert into public.winter_trees(slug,owner_id) values(username,new.id)
    on conflict (owner_id) do nothing;
  end if;
  return new;
end;
$$;

create trigger winter_sync_tree_metadata
  after update of raw_app_meta_data on auth.users
  for each row
  when (old.raw_app_meta_data->>'winter_username' is distinct from new.raw_app_meta_data->>'winter_username')
  execute function public.winter_register_tree();

insert into public.winter_trees(slug,owner_id)
select raw_app_meta_data->>'winter_username', id
from auth.users
where raw_app_meta_data->>'winter_username' ~ '^[a-z][a-z0-9_-]{2,23}$'
on conflict do nothing;
commit;
