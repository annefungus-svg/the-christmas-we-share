import {handle} from '../../api/tree.mjs';

export const config = {path:'/api/tree'};

export default function tree(request, context) {
  const settings = {...process.env, APP_ORIGIN:process.env.APP_ORIGIN || process.env.URL};
  return handle(request, {settings, platform:'netlify', visitorIP:context.ip});
}
