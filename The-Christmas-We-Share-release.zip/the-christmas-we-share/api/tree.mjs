import {createHmac} from 'node:crypto';
import {isIP} from 'node:net';
import {Buffer} from 'node:buffer';
import {gift,uuid} from '../lib/validation.mjs';

const cookieName='winter_owner';
const usernamePattern=/^[a-z][a-z0-9_-]{2,23}$/;
const accountEmail=username=>username+'@accounts.winter-tree.invalid';
const ownTree=user=>{
  const username=user?.app_metadata?.winter_username;
  return typeof username==='string'&&usernamePattern.test(username)?username:null;
};
function response(data,status=200,headers={}){
  return Response.json(data,{status,headers:{'Cache-Control':'no-store',...headers}});
}
function config(settings){
  const {SUPABASE_URL:url,SUPABASE_ANON_KEY:anon,SUPABASE_SERVICE_ROLE_KEY:secret,
    OWNER_USER_ID:owner,RATE_LIMIT_SECRET:salt,APP_ORIGIN:origin}=settings;
  if(!url||!anon||!secret||(owner&&!uuid.test(owner))||!salt||salt.length<32||!origin)return null;
  return {url:new URL(url).origin,anon,secret,owner,salt,origin:new URL(origin).origin};
}
async function upstream(env,path,{method='GET',body,token,privileged=false}={}){
  const key=privileged?env.secret:env.anon;
  const headers={apikey:key,'Content-Type':'application/json'};
  if(token||key.startsWith('eyJ'))headers.Authorization='Bearer '+(token||key);
  const result=await fetch(env.url+path,{method,headers,body:body===undefined?undefined:JSON.stringify(body),signal:AbortSignal.timeout(8000)});
  return {ok:result.ok,data:await result.json().catch(()=>null)};
}
function sessionCookie(token,seconds,env){
  return cookieName+'='+token+'; HttpOnly; SameSite=Strict; Path=/api; Max-Age='+seconds+(env.origin.startsWith('https:')?'; Secure':'');
}
async function readBody(request,maxBytes){
  const reader=request.body?.getReader();
  if(!reader)throw Error();
  let total=0, value='';
  const decoder=new TextDecoder('utf-8',{fatal:true});
  try{
    while(true){
      const part=await reader.read();
      if(part.done)break;
      total+=part.value.length;
      if(total>maxBytes)throw Error();
      value+=decoder.decode(part.value,{stream:true});
    }
    const data=JSON.parse(value+decoder.decode());
    if(!data||typeof data!=='object'||Array.isArray(data))throw Error();
    return data;
  }catch(error){await reader.cancel().catch(()=>{});throw error;}
}
async function rate(env,addr,action){
  if(!addr||!isIP(addr))return null;
  const bucket=createHmac('sha256',env.salt).update(action+':'+addr).digest('hex');
  const result=await upstream(env,'/rest/v1/rpc/winter_take_rate',{method:'POST',privileged:true,body:{bucket,action}});
  return result.ok&&typeof result.data==='boolean'?result.data:null;
}
export async function handle(request,{settings=process.env,platform=settings.VERCEL==='1'?'vercel':'local',visitorIP}={}){
  const ipHeader={vercel:'x-vercel-forwarded-for',cloudflare:'cf-connecting-ip',render:'x-forwarded-for'}[platform];
  const forwarded=ipHeader?request.headers.get(ipHeader):null;
  const clientIP=platform==='netlify'?visitorIP:platform==='render'?forwarded?.split(',').at(-1)?.trim():ipHeader?forwarded?.trim():'127.0.0.1';
  try{
    const query=new URL(request.url).searchParams;
    const action=query.get('action')||'public', tree=query.get('tree')||null;
    if(tree!==null&&!usernamePattern.test(tree))return response({error:'找不到这棵圣诞树。'},404);
    const treeFilter=tree?'eq.'+tree:'is.null';
    if(!['public','list','session','login','signup','logout','gift','favorite','delete'].includes(action))return response({error:'找不到此操作。'},404);
    const method=['public','list','session'].includes(action)?'GET':'POST';
    if(request.method!==method)return response({error:'请求方式无效。'},405,{Allow:method});
    const env=config(settings);
    if(!env){
      const local=['localhost','127.0.0.1','[::1]'].includes(new URL(request.url).hostname);
      if(platform==='local'&&local)
        return response({demo:true,error:'此预览仅展示互动效果。配置数据库后可收取寄语。'},503);
      return response({error:'冬夜信箱还在准备中，请稍后再来。'},503);
    }
    if(method==='POST'&&(request.headers.get('origin')!==env.origin||request.headers.get('content-type')?.split(';')[0]!=='application/json'))return response({error:'请求来源或格式无效。'},403);
    if(action==='public'){
      if(tree){
        const existing=await upstream(env,'/rest/v1/winter_trees?select=slug&slug=eq.'+tree);
        if(!existing.ok)throw Error();
        if(!existing.data?.length)return response({error:'找不到这棵圣诞树。'},404);
      }
      const result=await upstream(env,'/rest/v1/winter_ornaments?select=id,color,shape,scene_x,scene_y,outline,scene_angle&order=created_at.desc,id.asc&limit=30&tree_slug='+treeFilter);
      if(!result.ok)throw Error();
      return response(tree||env.owner?{items:result.data}:{items:result.data,acceptsGifts:false});
    }
    let body;
    if(method==='POST'){
      try{body=await readBody(request,action==='gift'?96000:8192);}catch{return response({error:'请求内容无效或过长。'},400);}
    }
    if(action==='logout')return response({ok:true},200,{'Set-Cookie':sessionCookie('',0,env)});
    if(['gift','login','signup'].includes(action)){
      const allowed=await rate(env,clientIP,action);
      if(allowed===null)throw Error();
      if(!allowed)return response({error:'提交太频繁，请稍后重试。'},429,{'Retry-After':'600'});
    }
    if(action==='gift'){
      if(!tree&&!env.owner)return response({error:'这棵展示树暂未开放收信。'},403);
      let data;
      try{data=gift(body);}catch(error){return response({error:error.message},400);}
      const result=await upstream(env,'/rest/v1/rpc/winter_add_gift',{method:'POST',privileged:true,body:{payload:tree?{...data,tree_slug:tree}:data}});
      if(!result.ok)throw Error();
      return response({ok:true},201);
    }
    if(action==='login'||action==='signup'){
      const username=typeof body.username==='string'?body.username.trim().toLowerCase():'';
      const password=body.password;
      if(typeof password!=='string'||!password.length||password.length>256)
        return response({error:'请输入有效的密码。'},400);
      if(action==='signup'){
        if(!usernamePattern.test(username)||password.length<10||Buffer.byteLength(password)>72)
          return response({error:'账号需为 3–24 个字符并以英文字母开头。密码至少 10 个字符，最多 72 字节。'},400);
        const existing=await upstream(env,'/rest/v1/winter_trees?select=slug&slug=eq.'+username);
        if(!existing.ok)throw Error();
        if(existing.data?.length)return response({error:'这个账号已被使用，请选一个新名字或直接登录。'},409);
        const created=await upstream(env,'/auth/v1/admin/users',{method:'POST',privileged:true,
          body:{email:accountEmail(username),password,email_confirm:true,app_metadata:{winter_username:username}}});
        if(!created.ok){
          if(['email_exists','user_already_exists'].includes(created.data?.code))
            return response({error:'这个账号已被使用，请选一个新名字或直接登录。'},409);
          if(created.data?.code==='weak_password')return response({error:'这个密码太容易猜了，请换一个。'},400);
          throw Error();
        }
      }
      const email=action==='signup'?accountEmail(username):body.email??(username.includes('@')?username:usernamePattern.test(username)?accountEmail(username):'');
      if(typeof email!=='string'||!email.length||email.length>254)return response({error:'请输入有效的账号。'},400);
      const auth=await upstream(env,'/auth/v1/token?grant_type=password',{method:'POST',body:{email:email.trim(),password}});
      const user=auth.data?.user, personal=ownTree(user);
      if(!auth.ok||!user?.email_confirmed_at||(!personal&&user.id!==env.owner)||!auth.data.access_token)
        return response({error:'无法登录，请检查账号和密码。'},401);
      return response({ok:true,tree:personal},200,{'Set-Cookie':sessionCookie(auth.data.access_token,Math.min(auth.data.expires_in||3600,3600),env)});
    }
    const token=request.headers.get('cookie')?.match(/(?:^|;\s*)winter_owner=([\w.-]+)/)?.[1];
    if(!token)return response({error:'请先登录主人账号。'},401);
    const user=await upstream(env,'/auth/v1/user',{token});
    if(!user.ok||!user.data?.email_confirmed_at||(tree?ownTree(user.data)!==tree:user.data.id!==env.owner))return response({error:'登录已失效，请重新登录。'},401);
    if(action==='session')return response({ok:true,tree});
    if(action==='list'){
      const id=query.get('id');
      if(id!==null&&!uuid.test(id))return response({error:'球体编号无效。'},400);
      const page=Number(query.get('page')||0);
      if(!Number.isInteger(page)||page<0||page>100000)return response({error:'页码无效。'},400);
      const fields='id,message,sender,song,url,favorite,created_at'+(id?',photo,winter_ornaments!inner(color,shape,outline)':',winter_ornaments!inner(id)');
      const result=await upstream(env,'/rest/v1/winter_gifts?select='+fields+'&order=created_at.desc,id.asc&limit=25&offset='+page*25+(id?'&id=eq.'+id:'')+'&winter_ornaments.tree_slug='+treeFilter,{token});
      if(!result.ok)throw Error();
      return response({items:result.data});
    }
    if(typeof body.id!=='string'||!uuid.test(body.id)||(action==='favorite'&&typeof body.favorite!=='boolean'))return response({error:'操作参数无效。'},400);
    const result=action==='favorite'
      ?await upstream(env,'/rest/v1/winter_gifts?id=eq.'+body.id,{method:'PATCH',token,body:{favorite:body.favorite}})
      :await upstream(env,'/rest/v1/winter_ornaments?id=eq.'+body.id+'&tree_slug='+treeFilter,{method:'DELETE',token});
    if(!result.ok)throw Error();
    return response({ok:true});
  }catch{return response({error:'冬夜信箱暂不可用，请稍后再试。'},503);}
}
export default {fetch:request=>handle(request)};
