# The Christmas We Share

一棵可旋转的冬夜圣诞树。朋友用水晶球送出歌曲和私人寄语，主人登录后可以拆球、打开歌曲、收藏和管理来信。

## 本机预览

部署配置使用 Node.js 22。解压后进入项目目录，运行 `npm run dev`，浏览器打开 <http://localhost:3000>。项目没有安装依赖的步骤。
本机空配置时显示互动预览，可以旋转、听原创冬夜铃琴循环、选色和试挂。试挂的球只保留在当前画面，刷新即重置，表单内容不会入库。需要退出本地服务器时按 Ctrl+C。

- 拖动、触屏横向拖动、方向按钮，或聚焦树后用左右方向键旋转。
- 点击圆球。真实来信会向访客显示封存状态，主人登录后可直接打开。
- 选位时可横向拖动旋转树，点击画面选位置，然后预览并确认发送。主人登录后可从顶部汇总信箱浏览寄语，进入单颗挂饰可打开记忆照片。直接音频链接会尝试自动播放，平台分享链接可从寄语页打开。
- 手势按钮会载入固定版本的 MediaPipe JS、WASM 与手部模型，随后请求摄像头权限。画面在当前浏览器推理。张开一只手触发雪花，单手指尖比心或双手比心触发爱心，竖起拇指触发星光。再次点击按钮可关闭摄像头。
- MP3、WAV、OGG、M4A 与 AAC 直链提供浏览器播放器。平台分享链接通过「打开歌曲」前往对应平台。歌名与歌曲链接均可留空，只写寄语也可以送出。已有部署需执行 `20261115000500_optional_song.sql`。
- WebGL 不可用时展示静态树并保留表单和球体按钮。启用系统「减少动态效果」会关闭微雪与拆球动画。
- 新树从空树开始，收到来信后显示最近 30 颗真实挂饰。主人信箱按页显示全部来信，每页 25 封。

## 配置 Supabase

1. 新建 Supabase 项目。在 SQL Editor 按文件名顺序运行 `supabase/migrations/` 下的迁移。每个迁移应当执行一次，数据库对象统一以 `winter_` 开头。
2. 如需让首页树收信，在 Authentication → Users 新建树主人的邮箱密码账号，确认邮箱。记录用户 UUID。
3. 如启用首页树，在 SQL Editor 将下方 UUID 替换为该账号的 UUID，登记为树主人。
   ```sql
   insert into public.winter_owner (singleton,user_id)
   values (true,'替换成主人 UUID')
   on conflict (singleton) do update set user_id=excluded.user_id;
   ```
4. 本地联调时，将 `.env.example` 复制为 `.env.local` 并填入以下参数，然后重启。部署时在 Vercel 项目设置填写同样的变量。

| 变量 | 内容 |
| --- | --- |
| `APP_ORIGIN` | 正式站点的完整来源，如 `https://your-tree.vercel.app`，本地为 `http://localhost:3000` |
| `SUPABASE_URL` | Supabase 项目 URL |
| `SUPABASE_ANON_KEY` | publishable key 或 legacy anon key |
| `SUPABASE_SERVICE_ROLE_KEY` | 服务端使用的 secret key 或 legacy service_role key |
| `OWNER_USER_ID` | 首页树主人的 UUID，与 `winter_owner` 一致。只使用个人树时可留空 |
| `RATE_LIMIT_SECRET` | 随机服务端密钥，可用 `openssl rand -hex 32` 生成 |

密钥填在服务端项目设置或本机忽略文件中。前端目录 `public/` 可公开发布。

## 部署到 Vercel

1. 把整个项目目录导入 Git 仓库并连接 Vercel，或在项目目录用 Vercel CLI 部署。Framework Preset 选择 **Other**，Root Directory 指向本项目。仓库内的 `vercel.json` 指定 `public` 为静态输出，`api/tree.mjs` 由 Node.js Functions 提供服务。
2. 在 Vercel 设置上表的 Production 环境变量。使用分配的 `.vercel.app` 域名即可，自定义域名可选。若先完成首次部署来确定域名，填入正式 `APP_ORIGIN` 后重新部署。验收成功后分享最终的正式 HTTPS 地址。线上缺少配置时会显示信箱暂不可用。
3. 在浏览器隐私窗口发送一条测试信。确认游客只能看到封存球，并且 `/api/tree?action=list` 返回 401。再用已验证的主人账号开启、收藏、删除。重新打开两种窗口确认状态已更新。用手机实际试一次摄像头手势。首次加载手势模型需要能访问 jsDelivr 与 Google 托管的模型。
4. Vercel Preview 地址每次可能变化。需要在预览地址实测写入时，应对该环境设置匹配的 `APP_ORIGIN`，并使用独立测试数据库。

## 权限与数据

- 公开表存球体颜色、随机 ID 和创建时间。公开 API 输出 ID、配色、造型、位置和手绘轮廓。私人表存署名、寄语、歌曲、链接和收藏状态。
- 主人先通过 Supabase Auth 验证邮箱密码和预设 UUID。会话放在 HttpOnly、SameSite=Strict Cookie 中，HTTPS 下启用 Secure，会话最多一小时。读写前重新向 Supabase 核验身份，并凭用户令牌访问数据库，由 RLS 再次核对登记的主人。
- 访客 API 校验来源、JSON 大小、字段、字符长度及 HTTPS URL。写入经专用数据库函数同时建立公开球和私人记录。直接从 Supabase 匿名访问无写入权限。
- 固定 10 分钟窗口，每个来源 IP 最多 5 次送礼尝试和 8 次登录尝试。Vercel 使用平台提供的客户端 IP。数据库持久保存限流计数与带密钥哈希，连续窗口之间独立计数。限流服务异常时暂停提交。
- 歌曲链接由朋友提供。网页渲染寄语时按纯文本处理，歌曲直链播放器仅在登录后展示，外部平台在新标签页打开。

## 检查

- `npm test` 运行 Node 自动测试，含输入校验、缺配置、匿名越权、跨站提交、请求过大、限流、主人登录和编辑授权。上游 Supabase 使用模拟响应。
- `tests/rls.sql` 在已迁移且配置主人 UUID 的测试 Supabase SQL Editor 执行。它覆盖匿名读公开球／拒绝私信和写入、其他登录用户的访问限制、主人读写与级联删除及限流。脚本使用事务并回滚测试数据。
- 本次交付检查过桌面和 390px 手机宽度的页面、实时 3D、旋转、音乐与预览挂球。真实 Supabase 权限测试、真机摄像头识别与 Vercel 线上测试需在配置后执行。

## 文件布局

- `public/` 原生页面、WebGL 三维场景、MediaPipe 手势和原创配乐
- `api/tree.mjs` 同源 API 和主人会话
- `lib/` 服务器输入校验
- `supabase/migrations/` 数据表、RLS、访客提交和限流函数
- `tests/` API 测试及数据库权限检查

官方参考 [Supabase RLS](https://supabase.com/docs/guides/database/postgres/row-level-security) · [Vercel Node.js Functions](https://vercel.com/docs/functions/runtimes/node-js) · [Vercel 客户端请求头](https://vercel.com/docs/headers/request-headers) · [MediaPipe Hand Landmarker](https://ai.google.dev/edge/mediapipe/solutions/vision/hand_landmarker/web_js)

## 记忆水晶

选色区会实时显示玻璃球。照片支持 12 MB 以内的 JPG、PNG 或 WebP，浏览器将其居中裁成 288 × 288 像素的缩略图，重新编码为 JPEG，清除源文件元数据。玻璃边缘虚化与磨砂效果在显示时叠加。可在提交前移除照片。

公开树显示低饱和球体。照片随寄语存入私人表，主人打开单颗球时才取回。演示模式中可重新点击试挂的球查看效果。已有部署只运行新增迁移 `20261115000200_memory_crystal.sql`，再更新网站代码。


## 挂饰造型与摆放

可选圆珠、冰滴、星星和雪花。填写后点击「选择摆放位置」，在整幅树景点击，或用方向键微调，再确认。自选位置相对于树景固定，旋转树体时可保留原有构图。公开接口只提供挂饰 ID、配色、造型和位置，照片与寄语保持私密。已有部署需在记忆水晶迁移后执行 `20261115000300_ornament_placement.sql` 再更新网站代码。

挂饰选择另有礼物盒和手绘轮廓。使用鼠标或触屏画一条连续外轮廓，松开即自动闭合，实时显示磨砂效果。手绘轮廓随挂饰在公开树景展示。已部署站点需执行 `20261115000400_drawn_ornaments.sql`。


## 每位朋友自己的树

登录和新建账号都在树景页。新建账号只需唯一用户名和密码，首字母为英文，大小写视为同名。生成的公开地址形如 `https://你的域名/?tree=snow-night`。账号名出现在分享链接中。密码由 Supabase Auth 处理，站点不收集真实邮箱。页面会提示没有邮箱找回，以及不要使用常用密码或留下敏感信息。

部署个人树功能需应用 `20261115000600_personal_trees.sql`。保持 Supabase 的邮箱密码提供方启用，关闭 Supabase 的公开注册入口，由网站服务端限流创建账号。正式验收时分别注册两个名字，用访客提交一条只含寄语的挂饰，并确认其中一个树主无法打开另一个树的信箱。首页可作为展示入口，个人树的收信与首页树主人配置独立。

## 通过 GitHub 和 Cloudflare 上线

1. 将项目文件提交到 GitHub 仓库。仓库可以是私有的，访客访问 Cloudflare 的公开站点。保留 `.env.example`，实际密钥只填 Cloudflare Worker 的 Settings → Variables and Secrets。
2. 在 Cloudflare 控制台进入 Workers & Pages，选择从 Git 仓库导入此项目。项目根目录使用 `wrangler.jsonc`，部署命令为 `npx wrangler deploy`，前端无需构建。
3. 按前面的 Supabase 步骤执行数据库迁移，配置 Worker 的运行环境变量。将 `APP_ORIGIN` 设为实际分享地址的来源，例如 `https://the-christmas-we-share.你的子域.workers.dev`。变量和密钥需设在 Worker 运行环境中。
4. 确保该公开地址可在隐私窗口访问。创建一棵个人树，使用其链接从访客窗口挂饰，再登录验证寄语。使用另一个树主账号验证第一棵树的信箱权限。

[GitHub 连接方式](https://developers.cloudflare.com/workers/ci-cd/builds/git-integration/) · [静态资源与 Worker 绑定](https://developers.cloudflare.com/workers/static-assets/binding/)
