import {handle} from './api/tree.mjs';

export default {
  fetch(request, env) {
    if (new URL(request.url).pathname === '/api/tree') {
      return handle(request, {settings:env, platform:'cloudflare'});
    }
    return env.ASSETS.fetch(request);
  }
};
