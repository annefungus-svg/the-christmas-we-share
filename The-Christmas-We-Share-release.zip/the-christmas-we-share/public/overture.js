const overture = document.getElementById('overture');
const experience = document.getElementById('tree-experience');
const invitation = document.getElementById('invitation');
const advance = document.getElementById('advance');
const skip = document.getElementById('skip-overture');
const canvas = document.getElementById('starlight');
const context = canvas.getContext('2d');
const motion = matchMedia('(prefers-reduced-motion: reduce)');
const tau = Math.PI * 2;
let chapter = 0, frame = 0, width = 0, height = 0, changedAt = 0, startedAt = 0;
let seed = 724;
function random() {
  seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
  return seed / 4294967296;
}
const dust = Array.from({length: 180}, () => ({
  x: random(), y: random(), phase: random()*tau, size: .35+random()*1.1, depth: random()
}));
const garland = Array.from({length: 425}, (_, i) => {
  const t = i/424;
  return {t, phase: t*tau*5.6, jitter: random()-.5, size: .42+random()*1.25, spark: random()};
});
function point(x, y, radius, opacity, gold = false) {
  context.fillStyle = gold ? 'rgba(242,210,151,'+opacity+')' : 'rgba(217,231,222,'+opacity+')';
  context.beginPath();
  context.arc(x, y, radius, 0, tau);
  context.fill();
}
function flare(x,y,size,opacity) {
  context.save();
  context.translate(x,y);
  const light = context.createRadialGradient(0,0,0,0,0,size);
  light.addColorStop(0,'rgba(255,242,206,'+opacity+')');
  light.addColorStop(.17,'rgba(244,218,160,'+opacity*.5+')');
  light.addColorStop(1,'rgba(244,218,160,0)');
  context.fillStyle=light;
  context.fillRect(-size,-size,size*2,size*2);
  context.fillStyle='rgba(255,240,203,'+opacity*.76+')';
  context.beginPath();
  context.moveTo(0,-size*.83);
  context.quadraticCurveTo(size*.06,-size*.075,size*.68,0);
  context.quadraticCurveTo(size*.055,size*.06,0,size*.83);
  context.quadraticCurveTo(-size*.055,size*.06,-size*.68,0);
  context.quadraticCurveTo(-size*.06,-size*.075,0,-size*.83);
  context.fill();
  context.restore();
}
function resize() {
  if (!context || chapter === 2) return;
  width=canvas.clientWidth; height=canvas.clientHeight;
  const dpr=Math.min(devicePixelRatio||1,2);
  canvas.width=Math.round(width*dpr); canvas.height=Math.round(height*dpr);
  context.setTransform(dpr,0,0,dpr,0,0);
  requestDraw();
}
const ease = value => 1-Math.pow(1-value,3);
function draw(now) {
  frame=0;
  if (chapter === 2 || !width || !height) return;
  if(!startedAt)startedAt=now;
  const staticFrame=motion.matches;
  const time=staticFrame?4:(now-startedAt)/1000;
  const mix=chapter===1?(staticFrame?1:ease(Math.min(1,(now-changedAt)/950))):0;
  const scale=Math.min(width*.72,height*.55,520);
  const cx=width/2, cy=height*.465, tip=cy-scale*.47;
  context.clearRect(0,0,width,height);
  for(const d of dust){
    const x=d.x*width+8*Math.sin(time*.21+d.phase);
    const y=d.y*height+7*Math.cos(time*.28+d.phase);
    const shimmer=.22+.34*(.5+.5*Math.sin(time*1.15+d.phase));
    point(x,y,d.size,shimmer*(1-mix*.45),d.depth>.66);
    if(d.depth>.985)flare(x,y,7,shimmer*.65);
  }
  for(const p of garland){
    const spin=p.phase+time*.56;
    const radius=scale*(.035+.42*p.t);
    const x=cx+Math.cos(spin)*radius+p.jitter*scale*.025;
    const y=tip+p.t*scale*.91+Math.sin(spin)*radius*.18;
    const targetX=cx+Math.sin(p.phase*2.1)*scale*.92*p.t;
    const targetY=cy+Math.cos(p.phase*3.4)*scale*.12*p.t;
    const fade=(.38+.62*(.5+.5*Math.sin(time*2+p.phase*1.6)))*(1-mix*.82);
    const px=x+(targetX-x)*mix, py=y+(targetY-y)*mix;
    point(px,py,p.size,fade,p.spark>.27);
    if(p.spark>.983)flare(px,py,8,fade*.56);
  }
  flare(cx,tip+(cy-tip)*mix,scale*.125,(1-mix)*(.73+.15*Math.sin(time*1.8)));
  if(!staticFrame || (chapter===1&&mix<1))requestDraw();
}
function requestDraw() {
  if(context&&!frame&&chapter!==2)frame=requestAnimationFrame(draw);
}
function enterTree() {
  if(chapter===2)return;
  chapter=2;
  cancelAnimationFrame(frame);
  removeEventListener('resize',resize);
  motion.removeEventListener('change',requestDraw);
  overture.hidden=true;
  experience.inert=false;
  experience.classList.add('tree-arrival');
  document.getElementById('tree').focus({preventScroll:true});
}

overture.hidden=false;
experience.inert=true;
advance.addEventListener('click',()=>{
  if(chapter===1){enterTree();return;}
  chapter=1;
  changedAt=performance.now();
  overture.classList.add('show-invitation');
  invitation.hidden=false;
  invitation.tabIndex=-1;
  invitation.focus({preventScroll:true});
  advance.firstElementChild.textContent='去看圣诞树';
  requestDraw();
});
skip.addEventListener('click',enterTree);
addEventListener('resize',resize);
motion.addEventListener('change',requestDraw);
resize();
