import {crystalMarkup,preparePhoto,updateCrystal} from './crystal.js';
import {createTree,palette,ornamentShapes,paintOrnament,outlinePolygon} from './tree.js';
const $=id=>document.getElementById(id);
const dialog=$('dialog'), content=$('dialog-content');
const activeTree=new URL(location.href).searchParams.get('tree');
let inboxReady=false, demo=false, signedIn=false, currentGift=null, focusReturn=null;
let noticeTimer, sampleCrystal, placement;
function setSignedIn(value){
  signedIn=value;
  $('owner').textContent=value?'汇总信箱':'登录';
}
function notice(message){
  $('notice').textContent=message;clearTimeout(noticeTimer);
  noticeTimer=setTimeout(()=>$('notice').textContent='',5000);
}
async function api(action,body,page,id){
  const url='/api/tree?action='+action+(page===undefined?'':'&page='+page)+(id?'&id='+encodeURIComponent(id):'')+(activeTree?'&tree='+encodeURIComponent(activeTree):'');
  const res=await fetch(url,body===undefined?{}:{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
  const data=await res.json();
  if(!res.ok)throw Object.assign(Error(data.error),{status:res.status,demo:data.demo});
  return data;
}
function show(html){
  releaseGiftMusic();
  currentGift=null;
  content.innerHTML=html;
  if(!dialog.open){focusReturn=document.activeElement;dialog.showModal();}
  const title=$('dialog-title');title.tabIndex=-1;title.focus();
  const toggle=content.querySelector('.password-toggle');
  if(toggle){
    const password=$('account-password');
    toggle.onclick=()=>{
      const visible=password.type==='password';
      password.type=visible?'text':'password';
      toggle.textContent=visible?'隐藏':'显示';
      toggle.setAttribute('aria-label',visible?'隐藏密码':'显示密码');
    };
  }
}
function fieldError(message){const e=$('field-error');if(e)e.textContent=message;}
function bindForm(id,submit){
  $(id).addEventListener('submit',async event=>{
    event.preventDefault();
    const form=event.currentTarget, button=form.querySelector('[type=submit]');
    if(button.disabled)return;
    const values=Object.fromEntries(new FormData(form));
    button.disabled=true;fieldError('');
    try{await submit(values);}catch(error){if(form.isConnected)fieldError(error.message||'暂时无法完成。');}
    finally{button.disabled=false;}
  });
}
const tree=createTree($('tree'),$('ornaments'),openOrnament);
const themeSelect=$('tree-theme');
try{
  const theme=localStorage.getItem('winter-tree-theme');
  if(['green','silver','blue'].includes(theme))themeSelect.value=theme;
}catch{}
tree.setTheme(themeSelect.value);
themeSelect.onchange=()=>{
  tree.setTheme(themeSelect.value);
  try{localStorage.setItem('winter-tree-theme',themeSelect.value);}catch{}
};
$('left').onclick=()=>tree.rotate(-.45);
$('right').onclick=()=>tree.rotate(.45);
$('close').onclick=()=>dialog.close();
dialog.addEventListener('close',()=>{
  if(placement)return;
  releaseGiftMusic();
  currentGift=null;content.replaceChildren();
  if(focusReturn?.isConnected)focusReturn.focus();else $('give').focus();
});
async function updateTree(){
  try{
    const data=await api('public');
    inboxReady=true;demo=false;
    $('give').hidden=data.acceptsGifts===false;
    tree.setItems(data.items);
    $('count').textContent=data.items.length>=30?'最近 30 颗来信':data.items.length+' 颗来信';
  }catch(error){
    if(error.demo){inboxReady=true;demo=true;$('count').textContent='互动预览';}
    else {inboxReady=false;$('count').textContent=error.status===404?'找不到这棵树':'信箱暂不可用';}
  }
}
updateTree();
$('give').onclick=async()=>{
  if(!inboxReady)await updateTree();
  if($('give').hidden&& !placement){createPersonalTree();return;}
  if(!inboxReady){notice('冬夜信箱还在准备中，请稍后再来。');return;}
  show(`<h2 id="dialog-title">挂一颗圣诞球</h2><p>${demo?'本机预览 · 试挂后可拆开查看':'歌、寄语、署名和照片仅供树的主人查看。'}</p>
  <form id="gift-form"><div class="crystal-workbench">${crystalMarkup()}<fieldset><legend>水晶颜色</legend><div class="swatches">${Object.entries(palette).map(([value,[label,rgb]])=>`<label style="--swatch:${rgb.map(channel=>Math.round(channel*255)).join(' ')}"><input class="sr-only" type="radio" name="color" value="${value}" ${value==='gold'?'checked':''}><i aria-hidden="true"></i><span>${label}</span></label>`).join('')}</div></fieldset><label class="shape-label">挂饰造型<select name="shape">${Object.entries(ornamentShapes).filter(([value])=>value!=='reindeer').map(([value,label])=>`<option value="${value}">${value==='flake'?'雪花（长得像 Claude 版）':label}</option>`).join('')}</select></label>
  <div class="outline-editor" id="outline-editor" hidden>
    <p id="outline-guide">一笔画出轮廓，松开自动闭合。也可用方向键移动、回车落点。</p>
    <div id="outline-pad" tabindex="0" aria-label="手绘挂饰轮廓" aria-describedby="outline-guide"><div aria-hidden="true"></div></div>
    <button type="button" id="clear-outline">清空重画</button>
  </div></div>
  <div class="gift-details">
  <label>你的署名（选填）<input name="sender" maxlength="40" autocomplete="nickname"></label>
  <fieldset class="gift-song"><legend>你愿意分享一首你喜欢的圣诞歌吗？</legend>
    <label>歌名（选填）<input name="song" maxlength="120"></label>
    <label>歌曲链接（选填）<input type="url" name="url" maxlength="700" placeholder="https://"></label>
  </fieldset>
  <label>私人寄语<textarea name="message" maxlength="600" required></textarea></label>
  <div class="memory-actions"><input hidden id="photo-input" type="file" accept="image/jpeg,image/png,image/webp"><button id="choose-photo" type="button" class="photo-label" aria-describedby="photo-help"><i aria-hidden="true">＋</i> 记忆照片（选填）</button><button type="button" id="clear-photo" hidden>移除照片</button></div>
  <small id="photo-help">照片以磨砂玻璃质感呈现</small><p id="photo-status" class="photo-status" role="status"></p>
  <p id="field-error" class="error" role="alert"></p><button class="primary gift-submit" type="submit">选择摆放位置 <span aria-hidden="true">↗</span></button></div></form>`);
  const form=$('gift-form'), fileInput=$('photo-input'), clearPhoto=$('clear-photo');
  const figure=form.querySelector('.crystal-preview'), photoStatus=$('photo-status');
  let photo='', pending=false, revision=0, outline=[], drawing=null, cursor=[50,50];
  const shapeSelect=form.elements.shape, editor=$('outline-editor'), pad=$('outline-pad');
  const render=()=>{
    const color=form.elements.color.value;
    updateCrystal(figure,color,photo,shapeSelect.value,outline);
    paintOrnament(pad,color,'sphere');
    pad.firstElementChild.style.clipPath=outlinePolygon(outline);
  };
  function appendPoint(x,y){
    const last=outline.at(-1);
    if(last&&Math.hypot(x-last[0],y-last[1])<1.4)return;
    // Keep the whole gesture within the storage budget, even after slow drawing.
    if(outline.length>=120)outline=outline.filter((_,i)=>i%2===0);
    outline.push([x,y]);
    render();
  }
  function addPoint(event){
    const rect=pad.getBoundingClientRect();
    const clamp=n=>Math.round(Math.max(1,Math.min(99,n))*10)/10;
    appendPoint(clamp((event.clientX-rect.left)*100/rect.width),clamp((event.clientY-rect.top)*100/rect.height));
  }
  pad.onkeydown=event=>{
    const delta={ArrowLeft:[-10,0],ArrowRight:[10,0],ArrowUp:[0,-10],ArrowDown:[0,10]}[event.key];
    if(event.key==='Enter'){
      event.preventDefault();
      appendPoint(...cursor);
    }else if(delta){
      event.preventDefault();
      cursor=cursor.map((value,i)=>Math.max(1,Math.min(99,value+delta[i])));
      pad.style.setProperty('--cursor-x',cursor[0]+'%');
      pad.style.setProperty('--cursor-y',cursor[1]+'%');
    }
  };
  pad.onpointerdown=event=>{
    if(drawing!==null||event.button!==0)return;
    drawing=event.pointerId;outline=[];
    pad.setPointerCapture(event.pointerId);
    fieldError('');
    addPoint(event);
  };
  pad.onpointermove=event=>{if(event.pointerId===drawing)addPoint(event);};
  pad.onpointerup=event=>{if(event.pointerId===drawing){addPoint(event);drawing=null;}};
  pad.onlostpointercapture=()=>{drawing=null;};
  $('clear-outline').onclick=()=>{outline=[];render();};
  render();
  form.querySelector('.swatches').addEventListener('change',render);
  shapeSelect.addEventListener('change',()=>{editor.hidden=shapeSelect.value!=='custom';render();});
  const choosePhoto=$('choose-photo');
  choosePhoto.onclick=()=>fileInput.click();
  clearPhoto.onclick=()=>{
    revision++; pending=false; photo=''; fileInput.value='';
    photoStatus.textContent=''; clearPhoto.hidden=true; render();
    choosePhoto.focus();
  };
  fileInput.onchange=async()=>{
    const file=fileInput.files[0];
    if(!file)return;
    const version=++revision;
    pending=true; clearPhoto.hidden=false;
    photoStatus.textContent='正在准备照片…';
    try {
      const nextPhoto=await preparePhoto(file);
      if(version!==revision||!form.isConnected)return;
      photo=nextPhoto; photoStatus.textContent='照片已放入水晶球。'; render();
    }catch(error){
      if(version!==revision||!form.isConnected)return;
      fileInput.value='';
      clearPhoto.hidden=!photo;
      photoStatus.textContent=error.message+(photo?' 已保留上一张照片。':'');
    }finally{
      if(version===revision)pending=false;
    }
  };
  bindForm('gift-form',async values=>{
    if(pending)throw Error('请等照片预览完成后再提交。');
    values.photo=photo;
    if(values.shape==='custom'){
      const extents=[0,1].map(axis=>outline.map(point=>point[axis]));
      if(outline.length<4||extents.some(axis=>Math.max(...axis)-Math.min(...axis)<10))throw Error('请先画一个完整的外轮廓。');
      values.outline=outline;
    }
    if(!values.message.trim())throw Error('请写下一句寄语。');
    if(values.url.trim()&&!safeLink(values.url.trim()))throw Error('请输入有效的 HTTPS 歌曲链接。');
    startPlacement(values);
  });
};
const surface=$('placement-surface'), marker=$('placement-marker'), placementControls=$('placement-controls');
const confirmPlacement=$('placement-confirm'), cancelPlacement=$('placement-cancel');
const review=$('gift-review');
let placementPointer=null, dragged=false, sendingGift=false;
function movePlacement(x,y){
  placement.scene_x=Math.max(.025,Math.min(.975,x));
  placement.scene_y=Math.max(.025,Math.min(.975,y));
  placement.scene_angle=tree.getAngle();
  tree.setDraft(placement,marker);
}
function startPlacement(values){
  placement={...values};
  paintOrnament(marker,values.color,values.shape,values.outline);
  movePlacement(.53,.52);
  dialog.close();
  surface.hidden=false;
  placementControls.hidden=false;
  $('give').hidden=true;
  surface.focus({preventScroll:true});
}
function finishPlacement(){
  placement=null;
  tree.setDraft(null);
  surface.hidden=true;
  placementControls.hidden=true;
  $('give').hidden=false;
}
surface.onpointerdown=event=>{
  if(event.button!==0||placementPointer)return;
  dragged=false;
  placementPointer={id:event.pointerId,start:event.clientX,last:event.clientX};
  surface.setPointerCapture(event.pointerId);
};
surface.onpointermove=event=>{
  if(event.pointerId!==placementPointer?.id)return;
  const {start,last}=placementPointer;
  if(!dragged&&Math.abs(event.clientX-start)<6)return;
  tree.rotate((event.clientX-last)*.012);
  dragged=true;
  placementPointer.last=event.clientX;
};
surface.onlostpointercapture=()=>{placementPointer=null;};
surface.onclick=event=>{
  if(!placement)return;
  if(!event.detail){confirmPlacement.click();return;}
  if(dragged)return;
  const rect=surface.getBoundingClientRect();
  movePlacement((event.clientX-rect.left)/rect.width,(event.clientY-rect.top)/rect.height);
};
surface.onkeydown=event=>{
  const delta={ArrowLeft:[-.022,0],ArrowRight:[.022,0],ArrowUp:[0,-.022],ArrowDown:[0,.022]}[event.key];
  if(event.key==='Escape'){cancelPlacement.click();return;}
  if(!delta||!placement)return;
  event.preventDefault();
  const rect=surface.getBoundingClientRect(), point=marker.getBoundingClientRect();
  const x=marker.hidden ? .5 : (point.left+point.width/2-rect.left)/rect.width;
  const y=marker.hidden ? .52 : (point.top+point.height/2-rect.top)/rect.height;
  movePlacement(x+delta[0],y+delta[1]);
};
cancelPlacement.onclick=()=>{
  finishPlacement();
  dialog.showModal();
  $('dialog-title').focus();
};
review.addEventListener('close',()=>{
  if(review.open)return;
  if(placement)surface.focus({preventScroll:true});
  review.replaceChildren();
});
review.addEventListener('cancel',event=>{if(sendingGift)event.preventDefault();});
confirmPlacement.onclick=()=>{
  if(!placement||review.open)return;
  review.innerHTML='<div class="panel"><h2 id="review-title" tabindex="-1">确认这份冬夜来信</h2>'+crystalMarkup()+'<p id="review-sender"></p><p id="review-message" class="message"></p><p id="review-song"></p><p id="review-error" class="error" role="alert"></p><div class="actions"><button id="review-back" type="button">返回选位</button><button class="primary" id="review-send" type="button">确认挂上 ↗</button></div></div>';
  const values=placement;
  updateCrystal(review.querySelector('.crystal-preview'),values.color,values.photo,values.shape,values.outline);
  $('review-sender').textContent=values.sender.trim()||'匿名';
  $('review-message').textContent=values.message.trim();
  $('review-song').textContent=[values.song.trim(),values.url.trim()].filter(Boolean).join(' · ');
  $('review-song').hidden=!$('review-song').textContent;
  $('review-back').onclick=()=>review.close();
  $('review-send').onclick=sendPlacement;
  review.showModal();
  $('review-title').focus();
};
async function sendPlacement(){
  if(!placement||sendingGift)return;
  sendingGift=true;
  const send=$('review-send'), back=$('review-back'), errorText=$('review-error');
  send.disabled=back.disabled=true;
  errorText.textContent='';
  const values=placement;
  try{
    if(demo){
      const {color,shape,scene_x,scene_y,scene_angle,photo,outline}=values;
      sampleCrystal={color,shape,photo,outline};
      tree.setItems([{id:'sample-preview',color,shape,scene_x,scene_y,scene_angle,outline}]);
    }else{
      await api('gift',values);
      await updateTree();
    }
    finishPlacement();
    review.close();
    content.replaceChildren();
    tree.snow();
    if(demo)showSampleCrystal();else { $('give').focus();notice('礼物已挂好。'); }
  }catch(error){
    errorText.textContent=error.message;
  }finally{
    sendingGift=false;
    send.disabled=back.disabled=false;
  }
}
function treeLink(tree){
  const url=new URL('/',location.origin);
  if(tree)url.searchParams.set('tree',tree);
  return url.href;
}
function shareTree(tree,created=false){
  show(`<h2 id="dialog-title">${created?'你的圣诞树准备好了':'分享我的圣诞树'}</h2>
  <p>把这条链接发给朋友，就能邀请她们来挂饰和留言。</p>
  <label>分享链接<input id="share-url" readonly></label>
  <div class="actions"><button class="primary" id="copy-tree">复制链接</button><a id="visit-tree">打开我的树 ↗</a></div>`);
  const url=treeLink(tree);
  $('share-url').value=url;
  $('visit-tree').href=url;
  $('copy-tree').onclick=async()=>{
    try{await navigator.clipboard.writeText(url);notice('分享链接已复制。');}
    catch{$('share-url').select();notice('请复制选中的分享链接。');}
  };
}
function createPersonalTree(){
  show(`<h2 id="dialog-title">创建我的圣诞树</h2>
  <p>用一个独一无二的账号和密码创建自己的树。账号名会出现在公开分享链接里。</p>
  <form id="signup-form">
  <label>账号<input name="username" autocomplete="username" required minlength="3" maxlength="24" pattern="[A-Za-z][A-Za-z0-9_\\-]{2,23}" autocapitalize="none" spellcheck="false" aria-describedby="name-hint"></label>
  <small id="name-hint">3–24 个字符，以英文字母开头，可用数字、连字符和下划线，大小写视为同名。</small>
  <div class="password-field"><label for="account-password">密码</label><input id="account-password" type="password" name="password" autocomplete="new-password" required minlength="10" maxlength="72"><button type="button" class="password-toggle" aria-label="显示密码" aria-controls="account-password">显示</button></div>
  <p class="account-note">这是适合节日互动的基础登录，安全级别有限。不验证邮箱，也没有邮件找回。请用这棵树专用的密码，避免留下敏感信息。</p>
  <p id="field-error" class="error" role="alert"></p>
  <div class="actions"><button type="submit" class="primary" ${demo?'disabled':''}>创建并生成链接</button><button type="button" id="already-registered">已有账号，去登录</button></div>
  ${demo?'<p>本机预览可体验界面。正式站点开放注册。</p>':''}</form>`);
  $('already-registered').onclick=login;
  bindForm('signup-form',async values=>{
    const result=await api('signup',values);
    setSignedIn(result.tree===activeTree);
    if(dialog.open&&$('signup-form'))shareTree(result.tree,true);
  });
}
function login(){
  show(`<h2 id="dialog-title">登录</h2><p>${demo?'本机预览 · 正式站点开放登录。':'用你的账号和密码打开私密信箱。'}</p>
  <form id="login-form"><label>账号<input name="username" autocomplete="username" autocapitalize="none" required maxlength="254"></label>
  <div class="password-field"><label for="account-password">密码</label><input id="account-password" type="password" name="password" autocomplete="current-password" required maxlength="256"><button type="button" class="password-toggle" aria-label="显示密码" aria-controls="account-password">显示</button></div>
  <p id="field-error" class="error" role="alert"></p><div class="actions"><button type="submit" class="primary" ${demo?'disabled':''}>登录</button><button type="button" id="register-from-login">创建我的树</button></div></form>`);
  $('register-from-login').onclick=createPersonalTree;
  bindForm('login-form',async values=>{
    const result=await api('login',values);
    setSignedIn(result.tree===activeTree);
    if(!dialog.open||!$('login-form'))return;
    if(signedIn)await archive();
    else shareTree(result.tree);
  });
}
function safeLink(value){
  try{const url=new URL(value);return url.protocol==='https:'&&!url.username&&!url.password?url.href:null;}catch{return null;}
}
async function archive(page=0){
  const {items}=await api('list',undefined,page);
  setSignedIn(true);
  show('<h2 id="dialog-title">汇总信箱</h2><ul class="archive" id="archive-items"></ul><div class="actions"><button id="prev-page">上一页</button><button id="next-page">下一页</button><button id="share-tree">分享我的树</button><button id="logout">退出登录</button></div>');
  if(!items.length){const li=document.createElement('li');li.textContent=page?'已经到最后一页。':'树上还没有收到来信。';$('archive-items').append(li);}
  for(const item of items){
    const li=document.createElement('li'),button=document.createElement('button');
    button.textContent=(item.favorite?'★ ':'✧ ')+(item.sender||'匿名')+' · '+(item.song||(item.url?'一首歌':'圣诞寄语'));
    button.onclick=()=>{
      startBackground();
      openGift(item.id,page).catch(handleOwnerError);
    };
    const message=document.createElement('p');
    message.className='archive-message';
    message.textContent=item.message;
    li.append(button,message);$('archive-items').append(li);
  }
  $('prev-page').hidden=page===0;$('next-page').hidden=items.length<25;
  $('prev-page').onclick=()=>archive(page-1).catch(handleOwnerError);
  $('next-page').onclick=()=>archive(page+1).catch(handleOwnerError);
  $('share-tree').onclick=()=>shareTree(activeTree);
  $('logout').onclick=async()=>{try{await api('logout',{});setSignedIn(false);dialog.close();notice('已退出主人账号。');}catch(e){notice(e.message);}};
}
function handleOwnerError(error){
  if(error.status===401||error.demo){setSignedIn(false);login();}
  else notice(error.message);
}
$('owner').onclick=()=>archive().catch(handleOwnerError);
async function openGift(id,page=0){
  const {items}=await api('list',undefined,undefined,id);
  if(items[0])reveal(items[0],page);
  else notice('这颗球已移除。');
}
function reveal(item,page=0){
  show('<h2 id="dialog-title" class="reveal">一颗冬夜来信</h2><p id="sender"></p><p id="message" class="message"></p><p id="song"></p><div class="actions"><button id="favorite"></button><button id="back">返回信箱</button><button id="remove">删除</button></div>');
  currentGift=item;
  if(item.photo) {
    $('dialog-title').insertAdjacentHTML('afterend',crystalMarkup());
    const figure=content.querySelector('.crystal-preview');
    updateCrystal(figure,item.winter_ornaments?.color,item.photo,item.winter_ornaments?.shape,item.winter_ornaments?.outline);
    const view=document.createElement('button');
    view.type='button';view.className='photo-open';view.textContent='查看照片 ↗';
    figure.after(view);
    figure.querySelector('.crystal').onclick=()=>view.click();
    view.onclick=()=>{
      $('full-photo').src=item.photo;
      $('photo-viewer').showModal();
      $('photo-close').focus();
    };
  }
  $('sender').textContent=item.sender||'匿名朋友';
  $('message').textContent=item.message;
  const link=safeLink(item.url);
  $('song').hidden=!item.song&&!link;
  $('song').textContent=item.song||(link?'朋友送来了一首歌':'');
  if(link){
    const a=document.createElement('a');a.href=link;a.target='_blank';a.rel='noopener noreferrer';a.textContent='打开歌曲 ↗';
    $('song').append('　',a);
    if(/\.(mp3|wav|ogg|opus|m4a|aac|flac)$/i.test(new URL(link).pathname)){
      const player=document.createElement('audio');player.src=link;player.controls=true;player.preload='metadata';
      player.setAttribute('aria-label','播放朋友送来的歌');$('song').after(player);
      giftAudio=player;
      player.addEventListener('play',()=>{if(giftAudio===player){audio.pause();syncMusic();}});
      player.addEventListener('pause',()=>{if(giftAudio===player){syncMusic();startBackground();}});
      player.addEventListener('ended',()=>{if(giftAudio===player){syncMusic();startBackground();}});
      if(musicPreference!==false)player.play().catch(()=>{});
    }
  }
  $('favorite').textContent=item.favorite?'★ 已收藏':'☆ 收藏';
  $('favorite').setAttribute('aria-pressed',String(item.favorite));
  $('favorite').onclick=()=>favorite(item).catch(handleOwnerError);
  $('back').onclick=()=>archive(page).catch(handleOwnerError);
  $('remove').onclick=()=>{
    show('<h2 id="dialog-title">删除这颗圣诞球？</h2><p>球体、寄语和歌曲将一同移除。</p><div class="actions"><button id="confirm-remove" class="primary">确认删除</button><button id="cancel-remove">取消</button></div>');
    $('cancel-remove').onclick=()=>reveal(item,page);
    $('confirm-remove').onclick=async event=>{
      const button=event.currentTarget;button.disabled=true;
      try{await api('delete',{id:item.id});await updateTree();if(dialog.open&&button.isConnected)await archive(page);}
      catch(e){handleOwnerError(e);}
      finally{button.disabled=false;}
    };
  };
}
let saving=false;
async function favorite(item){
  if(saving)return;
  saving=true;
  try{
    const favorite=!item.favorite;
    await api('favorite',{id:item.id,favorite});item.favorite=favorite;
    if(currentGift===item){
      $('favorite').textContent=favorite?'★ 已收藏':'☆ 收藏';
      $('favorite').setAttribute('aria-pressed',String(favorite));
    }
  }finally{saving=false;}
}
function showSampleCrystal(){
  show('<h2 id="dialog-title">预览球已挂上</h2>'+crystalMarkup()+'<p>试挂仅保留在当前页面，刷新即清除。</p>');
  updateCrystal(content.querySelector('.crystal-preview'),sampleCrystal.color,sampleCrystal.photo,sampleCrystal.shape,sampleCrystal.outline);
}
async function openOrnament(record){
  startBackground();
  if(record.id==='sample-preview'&&sampleCrystal){showSampleCrystal();return;}
  if(signedIn){
    try{
      await openGift(record.id);
      return;
    }catch(error){if(error.status!==401){notice(error.message);return;}setSignedIn(false);}
  }
  show('<h2 id="dialog-title">封存的祝福</h2><p>这份歌和寄语，等树的主人来打开。</p><button class="primary" id="give-in-dialog">挂上我的圣诞球</button>');
  $('give-in-dialog').onclick=$('give').onclick;
}
api('session').then(()=>{setSignedIn(true);}).catch(()=>{});

const audio=new Audio('/winter.wav');
audio.preload='auto';audio.loop=true;audio.volume=.45;
let musicPreference=null, giftAudio=null;
$('photo-close').onclick=()=>$('photo-viewer').close();
$('photo-viewer').addEventListener('close',()=>$('full-photo').removeAttribute('src'));
function startBackground(){
  if(musicPreference===false||giftAudio&&!giftAudio.paused)return;
  audio.play().catch(()=>{});
}
function releaseGiftMusic(){
  if(!giftAudio)return;
  const previous=giftAudio;
  giftAudio=null;
  previous.pause();
  syncMusic();
  startBackground();
}
const syncMusic=()=>$('music').setAttribute('aria-pressed',String(!audio.paused||!!giftAudio&&!giftAudio.paused));
audio.addEventListener('play',syncMusic);
audio.addEventListener('pause',syncMusic);
$('music').onclick=async()=>{
  const playing=!audio.paused||giftAudio&&!giftAudio.paused;
  musicPreference=!playing;
  if(playing){
    audio.pause();giftAudio?.pause();syncMusic();return;
  }
  try{await (giftAudio||audio).play();syncMusic();}
  catch{notice('音乐暂时无法播放。');}
};
function gestureBurst(kind){
  const stage=$('tree').parentElement;
  stage.querySelector('.gesture-burst')?.remove();
  const burst=document.createElement('div');
  burst.className='gesture-burst '+kind;
  burst.setAttribute('aria-hidden','true');
  const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
  const amount=reduced?8:kind==='snow'?84:kind==='stars'?32:26;
  const symbols={heart:['♡','♥'],stars:['✦','✧','⋆'],snow:['❄','·','✧','❅']};
  for(let i=0;i<amount;i++){
    const particle=document.createElement('span');
    particle.textContent=symbols[kind][i%symbols[kind].length];
    particle.style.setProperty('--x',(kind==='snow'?Math.random()*100:17+Math.random()*66)+'%');
    particle.style.setProperty('--y',(kind==='stars'?12+Math.random()*67:65+Math.random()*25)+'%');
    particle.style.setProperty('--drift',(Math.random()*90-45)+'px');
    particle.style.setProperty('--delay',(i===0?0:Math.random()*(kind==='snow'?3.1:1.9))+'s');
    particle.style.setProperty('--size',(12+Math.random()*(kind==='heart'?39:kind==='stars'?35:24))+'px');
    burst.append(particle);
  }
  stage.append(burst);
  setTimeout(()=>burst.remove(),9400);
}
let gesture, loading=false, cameraGeneration=0;
$('camera').onclick=async()=>{
  if(loading){cameraGeneration++;loading=false;return;}
  if(gesture){gesture();gesture=null;$('camera').setAttribute('aria-pressed','false');notice('摄像头已关闭。');return;}
  const generation=++cameraGeneration;
  loading=true;notice('正在载入手势识别。请允许摄像头访问。');
  try{
    const {startGestures}=await import('./gestures.js');
    if(generation!==cameraGeneration)return;
    const stop=await startGestures($('camera-feed'),{
      snow:()=>{tree.snow();gestureBurst('snow');},
      heart:()=>gestureBurst('heart'),
      stars:()=>gestureBurst('stars')
    });
    if(generation!==cameraGeneration){stop();return;}
    gesture=stop;$('camera').setAttribute('aria-pressed','true');
    notice('单手指尖比心 · 张开手掌下雪 · 竖拇指点亮星光');
  }catch{if(generation===cameraGeneration)notice('摄像头或手势模型未就绪，仍可拖动、点击或用键盘操作。');}
  finally{if(generation===cameraGeneration)loading=false;}
};
addEventListener('pagehide',()=>{cameraGeneration++;loading=false;gesture?.();gesture=null;$('camera').setAttribute('aria-pressed','false');});
