export const palette = {
  gold: ['香槟金', [.90,.81,.64]], ice: ['冰晶蓝',[.68,.79,.84]],
  rose: ['玫瑰粉',[.85,.68,.72]], mint: ['薄荷绿',[.67,.81,.74]],
  silver: ['月光银',[.80,.83,.86]]
};
export const ornamentShapes = {
  sphere:'圣诞球', drop:'冰滴', star:'星星', flake:'雪花', present:'礼物盒', reindeer:'驯鹿', custom:'手绘轮廓'
};
export function outlinePolygon(outline){
  if(!Array.isArray(outline)||!outline.length)return 'polygon(0 0,0 0,0 0)';
  return 'polygon(evenodd,'+outline.map(([x,y])=>Number(x)+'% '+Number(y)+'%').join(',')+')';
}
function fitOutline(outline){
  if(!outline?.length)return [];
  const bounds=[0,1].map(axis=>{
    const values=outline.map(point=>point[axis]);
    return [Math.min(...values),Math.max(...values)];
  });
  const size=Math.max(...bounds.map(([min,max])=>max-min),1);
  return outline.map(point=>point.map((value,axis)=>{
    const [min,max]=bounds[axis];
    return Math.round((50+(value-(min+max)/2)*86/size)*10)/10;
  }));
}
export function paintOrnament(container,color,shape,outline){
  const [,rgb]=palette[color]||palette.gold;
  container.style.setProperty('--crystal-tint',rgb.map(channel=>Math.round(channel*255)).join(' '));
  container.dataset.shape=Object.hasOwn(ornamentShapes,shape)?shape:'sphere';
  if(shape==='custom')container.style.setProperty('--drawn-outline',outlinePolygon(fitOutline(outline)));
}
export function positionOrnament(element,x,y){
  element.style.left=(x*100)+'%';
  element.style.top=(y*100)+'%';
}
export const sample = Array.from({length:12},(_,i)=>({id:'sample-'+i,color:Object.keys(palette)[i%5],shape:Object.keys(ornamentShapes)[i%5]}));
const turn = Math.PI*2;
function random(seed) {
  return () => ((seed = (Math.imul(seed,1664525)+1013904223)>>>0)/4294967296);
}
const vertex = `precision mediump float;
attribute vec3 pos; attribute vec3 color; attribute float size;
varying vec3 tint; varying float depth;
uniform vec2 rot; uniform vec2 scale; uniform float pixel; uniform float mode; uniform float time;
void main(){
  vec3 p = pos;
  if(mode == 4.) {p.y=mod(p.y-time*size*.038+4.,4.)-0.4; p.x+=sin(time*.45+pos.z*4.)*.10;}
  if(mode != 4. && mode != 6.) p=vec3(p.x*rot.x+p.z*rot.y,p.y,p.z*rot.x-p.x*rot.y);
  float y=p.y-p.z*.11;
  float w=1.-p.z*.115;
  gl_Position=vec4(p.x*scale.x,y*scale.y-(mode==4.?0.:.794*w),-p.z*.28,w);
  gl_PointSize=size*pixel/w;
  tint=color;depth=p.z;
}`;
const fragment = `precision mediump float;
varying vec3 tint; varying float depth; uniform float mode; uniform float time;
void main(){
  vec2 p=gl_PointCoord*2.-1.; p.y=-p.y;
  float r=length(p); vec3 c=tint; float a=1.;
  if(mode==0.) {if(r>1.)discard; a=.75*(1.-smoothstep(.4,1.,r));}
  if(mode==1.) {if(r>1.)discard; a=exp(-4.*r*r)*(1.-smoothstep(.63,1.,r)); c=mix(tint,vec3(1.,.98,.85),exp(-32.*r*r));}
  if(mode==3.) {
    float angle=atan(p.y,p.x);
    float spoke=pow(abs(sin(angle*2.)),24.);
    a=max(exp(-r*8.),spoke*pow(max(0.,1.-r),2.))*(1.-smoothstep(.82,1.,r));
    c=mix(tint,vec3(1.,1.,.93),max(0.,1.-r*2.2));
  }
  if(mode==4.) {a=(1.-smoothstep(.1,1.,r))*(.50+.18*sin(time*.7+depth*3.));}
  gl_FragColor=vec4(c,a);
}`;
function program(gl) {
  const result=gl.createProgram();
  for(const [type,src] of [[gl.VERTEX_SHADER,vertex],[gl.FRAGMENT_SHADER,fragment]]){
    const shader=gl.createShader(type);
    gl.shaderSource(shader,src); gl.compileShader(shader);
    if(!gl.getShaderParameter(shader,gl.COMPILE_STATUS)) throw Error(gl.getShaderInfoLog(shader));
    gl.attachShader(result,shader); gl.deleteShader(shader);
  }
  gl.linkProgram(result);
  if(!gl.getProgramParameter(result,gl.LINK_STATUS)) throw Error(gl.getProgramInfoLog(result));
  return result;
}
const crown = y => 1.34 * Math.pow(Math.max(0,(2.57-y)/2.6),1.03);
function foliage(){
  const rand=random(140), needles=[], limbs=[], lights=[], snow=[];
  for(let i=0;i<320;i++){
    const level=i/320, y=.03+level*2.53, angle=i*2.39996;
    const length=crown(y)*(.68+rand()*.34)*(1-.16*Math.sin(level*46));
    const lean=.12+length*.17;
    limbs.push(0,y-.12,0,.19,.12,.066,1, Math.cos(angle)*length,y+lean,Math.sin(angle)*length,.18,.16,.08,1);
    for(let j=0;j<190;j++){
      const t=.18+.82*rand(), offset=(rand()-.5)*(.13+length*.23)*(1-t*.83);
      const branch=angle+offset/(t+.22);
      const radius=length*t*(.73+.27*rand());
      const hue=.40+rand()*.65;
      const frost=rand()<.067 ? .24 : 0;
      needles.push(Math.cos(branch)*radius,y+lean*t+(rand()-.52)*(.20+length*.14)*(1-t*.50),Math.sin(branch)*radius,
        .16*hue+frost,.40*hue+frost,.274*hue+frost,(2.1+rand()*3.5)*(1-.31*level));
    }
  }
  for(let i=0;i<240;i++){
    const fraction=i/240, y=.12+fraction*2.38, a=fraction*turn*7.4+(rand()-.5)*.5;
    const radius=crown(y)*(.82+.19*rand());
    lights.push(Math.cos(a)*radius,y,Math.sin(a)*radius,1,.65+rand()*.23,.30+rand()*.18,3+rand()*11);
  }
  for(let i=0;i<620;i++){
    const a=rand()*turn,r=Math.sqrt(rand())*1.95;
    lights.push(Math.cos(a)*r,-.10+rand()*.017,Math.sin(a)*r,.55+rand()*.25,.47,.26,1+rand()*3);
  }
  for(let i=0;i<210;i++) snow.push((rand()-.5)*7,(rand()*4), (rand()-.5)*5,.78,.86,.81,1+rand()*3);
  for(let i=0;i<26;i++){
    const a=i/26*turn;
    limbs.push(Math.cos(a)*.083,-.13,Math.sin(a)*.083,.28,.18,.11,1, Math.cos(a)*.049,1.5,Math.sin(a)*.049,.2,.15,.08,1);
  }
  return {needles,limbs,lights,snow};
}

export function createTree(canvas, overlay, open){
  const motion=matchMedia('(prefers-reduced-motion: reduce)');
  let gl, shader;
  try {gl=canvas.getContext('webgl',{alpha:true,antialias:true}); if(gl) shader=program(gl);} catch(error){console.warn(error);}
  let angle=.18, target=angle, items=[], frame=0, windUntil=0;
  let draw=()=>{};
  const refresh=()=>{if(!frame) frame=requestAnimationFrame(draw);};
  const rotate=delta=>{target+=delta;refresh();};
  const snow=()=>{windUntil=performance.now()+4500; refresh();};
  if(gl && shader){
    canvas.parentElement.classList.add('ready');
    gl.useProgram(shader);
    gl.enable(gl.BLEND);
    gl.blendFuncSeparate(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA,gl.ONE,gl.ONE_MINUS_SRC_ALPHA);
    gl.enable(gl.DEPTH_TEST);
    const attrs=['pos','color','size'].map(key=>gl.getAttribLocation(shader,key));
    const uniforms=Object.fromEntries(['rot','scale','pixel','mode','time'].map(key=>[key,gl.getUniformLocation(shader,key)]));
    const buffer=(values,dynamic=false)=>{
      const b=gl.createBuffer();
      return {bind(data){
        gl.bindBuffer(gl.ARRAY_BUFFER,b);
        if(data)gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(data),dynamic?gl.DYNAMIC_DRAW:gl.STATIC_DRAW);
      }};
    };
    const render=(entry,count,mode,primitive=gl.POINTS)=>{
      entry.bind();
      attrs.forEach((a,i)=>{gl.enableVertexAttribArray(a);gl.vertexAttribPointer(a,i===2?1:3,gl.FLOAT,false,28,[0,12,24][i]);});
      gl.uniform1f(uniforms.mode,mode);
      gl.drawArrays(primitive,0,count);
    };
    const shape=foliage();
    const geometry=Object.fromEntries(Object.entries(shape).map(([k,v])=>{const b=buffer(v);b.bind(v);return [k,b];}));
    const star=buffer([]);
    star.bind([0,2.63,0,1,.77,.39,84,0,2.63,0,1,.91,.67,44]);
    let particles=0;
    const resize=new ResizeObserver(refresh);resize.observe(canvas);
    draw=(now)=>{
      frame=0;
      const dpr=Math.min(devicePixelRatio||1,2), width=canvas.clientWidth,height=canvas.clientHeight;
      if(!width||!height)return;
      if(canvas.width!==Math.round(width*dpr)||canvas.height!==Math.round(height*dpr)){canvas.width=Math.round(width*dpr);canvas.height=Math.round(height*dpr);}
      angle=motion.matches?target:angle+(target-angle)*.19;
      const cos=Math.cos(angle),sin=Math.sin(angle);
      const sy=.645, sx=Math.min(sy*height/width,.94);
      gl.viewport(0,0,canvas.width,canvas.height);
      gl.clearColor(0,0,0,0);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
      gl.uniform2f(uniforms.rot,cos,sin);gl.uniform2f(uniforms.scale,sx,sy);
      gl.uniform1f(uniforms.pixel,dpr*Math.min(height/545,1.4));
      gl.uniform1f(uniforms.time,motion.matches?0:now/1000);
      gl.depthMask(true);render(geometry.limbs,shape.limbs.length/7,5,gl.LINES);
      render(geometry.needles,shape.needles.length/7,0);
      gl.depthMask(false);gl.blendFuncSeparate(gl.SRC_ALPHA,gl.ONE,gl.ONE,gl.ONE_MINUS_SRC_ALPHA);
      render(geometry.lights,shape.lights.length/7,1);render(star,2,3);
      for(const item of items){
        const {record,x,y,z,button}=item;
        if (record.scene_x != null && record.scene_y != null) continue;
        const dz=z*cos-x*sin, dx=x*cos+z*sin, w=1-dz*.115;
        const show=dz>-.04;
        button.hidden=!show;
        button.style.left=(50+50*dx*sx/w)+'%';
        button.style.top=(89.7-50*(y-dz*.11)*sy/w)+'%';
        button.style.zIndex=String(2+Math.round(dz*10+14));
      }
      gl.blendFuncSeparate(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA,gl.ONE,gl.ONE_MINUS_SRC_ALPHA);
      if(!motion.matches){
        particles=now<windUntil?210:95;
        gl.viewport(0,0,canvas.width,canvas.height);render(geometry.snow,particles,4);
      }
      gl.depthMask(true);
      if(!motion.matches||Math.abs(target-angle)>.001)refresh();
    };
    motion.addEventListener('change',refresh);
    canvas.addEventListener('webglcontextlost',e=>{
      e.preventDefault();cancelAnimationFrame(frame);frame=0;draw=()=>{};
      canvas.parentElement.classList.remove('ready');setItems(items.map(item=>item.record));
    });
    canvas.addEventListener('webglcontextrestored',()=>location.reload());
  }
  function setItems(records){
    overlay.replaceChildren();
    items=records.map((record,i)=>{
      const button=document.createElement('button'), [name]=palette[record.color]||palette.gold;
      button.className='orb-hit';button.setAttribute('aria-label',name+' · '+(ornamentShapes[record.shape]||ornamentShapes.sphere)+' '+(i+1));
      paintOrnament(button,record.color,record.shape,record.outline);
      button.onclick=()=>open(record);
      const a=i*2.39996+.8, y=.28+((i*19)%53)/53*1.85, r=crown(y)*.87+.03;
      if(record.scene_x != null && record.scene_y != null){
        positionOrnament(button,record.scene_x,record.scene_y);
        button.style.zIndex='32';
      }else{
        positionOrnament(button,.5+Math.cos(a)*r*.21,.87-y*.29);
      }
      overlay.append(button);
      return {record,x:Math.cos(a)*r,z:Math.sin(a)*r,y,button};
    });
    refresh();
  }
  let pointer=null;
  canvas.addEventListener('pointerdown',e=>{if(e.button!==0)return; pointer=e.clientX;canvas.setPointerCapture(e.pointerId);});
  canvas.addEventListener('pointermove',e=>{if(pointer!==null&&canvas.hasPointerCapture(e.pointerId)){rotate((e.clientX-pointer)*.012);pointer=e.clientX;}});
  canvas.addEventListener('lostpointercapture',()=>{pointer=null;});
  canvas.addEventListener('keydown',e=>{if(['ArrowLeft','ArrowRight'].includes(e.key)){e.preventDefault();rotate(e.key==='ArrowLeft'?-.35:.35);}});
  return {setItems,rotate,snow};
}
