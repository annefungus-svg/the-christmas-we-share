export const palette = {
  gold: ['香槟金', [.90,.81,.64]], ice: ['冰晶蓝',[.68,.79,.84]],
  rose: ['玫瑰粉',[.85,.68,.72]], mint: ['薄荷绿',[.67,.81,.74]],
  silver: ['月光银',[.80,.83,.86]]
};
export const ornamentShapes = {
  sphere:'圣诞球', drop:'冰滴', star:'星星', flake:'雪花', present:'礼物盒', reindeer:'驯鹿', custom:'手绘轮廓'
};
export function outlinePolygon(outline){
  if(!Array.isArray(outline)||!outline.length)return 'polygon(0 0,0 0,0 0)';
  return 'polygon(evenodd,'+outline.map(([x,y])=>Number(x)+'% '+Number(y)+'%').join(',')+')';
}
function fitOutline(outline){
  if(!outline?.length)return [];
  const bounds=[0,1].map(axis=>{
    const values=outline.map(point=>point[axis]);
    return [Math.min(...values),Math.max(...values)];
  });
  const size=Math.max(...bounds.map(([min,max])=>max-min),1);
  return outline.map(point=>point.map((value,axis)=>{
    const [min,max]=bounds[axis];
    return Math.round((50+(value-(min+max)/2)*86/size)*10)/10;
  }));
}
export function paintOrnament(container,color,shape,outline){
  const [,rgb]=palette[color]||palette.gold;
  container.style.setProperty('--crystal-tint',rgb.map(channel=>Math.round(channel*255)).join(' '));
  container.dataset.shape=Object.hasOwn(ornamentShapes,shape)?shape:'sphere';
  if(shape==='custom')container.style.setProperty('--drawn-outline',outlinePolygon(fitOutline(outline)));
}
export function positionOrnament(element,x,y){
  element.style.left=(x*100)+'%';
  element.style.top=(y*100)+'%';
}
const turn = Math.PI*2;
function random(seed) {
  return () => ((seed = (Math.imul(seed,1664525)+1013904223)>>>0)/4294967296);
}
const vertex = `precision mediump float;
attribute vec3 pos; attribute vec3 color; attribute float size;
varying vec3 tint; varying float depth;
uniform vec2 rot; uniform vec2 scale; uniform float pixel; uniform float mode; uniform float time;
void main(){
  vec3 p = pos;
  if(mode == 4.) {p.y=mod(p.y-time*size*.038+4.,4.)-0.4; p.x+=sin(time*.45+pos.z*4.)*.10;}
  if(mode != 4. && mode != 6.) p=vec3(p.x*rot.x+p.z*rot.y,p.y,p.z*rot.x-p.x*rot.y);
  float y=p.y-p.z*.11;
  float w=1.-p.z*.115;
  gl_Position=vec4(p.x*scale.x,y*scale.y-(mode==4.?0.:.794*w),-p.z*.28,w);
  gl_PointSize=size*pixel*(mode==4.?1.60:1.)/w;
  tint=color;depth=p.z;
}`;
const fragment = `precision mediump float;
varying vec3 tint; varying float depth; uniform float mode; uniform float time; uniform vec2 rot; uniform float theme;
void main(){
  vec2 p=gl_PointCoord*2.-1.; p.y=-p.y;
  float r=length(p); vec3 c=tint; float a=1.;
  if(mode==0.) {if(r>1.)discard; a=.75*(1.-smoothstep(.4,1.,r));}
  if(mode==1.) {if(r>1.)discard; a=exp(-4.*r*r)*(1.-smoothstep(.63,1.,r)); c=mix(tint,vec3(1.,.98,.85),exp(-32.*r*r));}
  if(mode==3.) {
    float angle=atan(p.y,p.x);
    float spoke=pow(abs(cos(angle*2.)),18.);
    a=max(exp(-r*6.),spoke*pow(max(0.,1.-r),1.45))*(1.-smoothstep(.82,1.,r));
    c=mix(tint,vec3(1.,1.,.93),max(0.,1.-r*2.2));
  }
  if(mode==6.) {
    vec2 rightSpark=p-vec2(.57,.29);
    vec2 leftSpark=p-vec2(-.53,-.25);
    float sparkRight=1.-smoothstep(.86,1.00,pow(abs(rightSpark.x)/.105,.66)+pow(abs(rightSpark.y)/.17,.66));
    float sparkLeft=1.-smoothstep(.86,1.00,pow(abs(leftSpark.x)/.074,.66)+pow(abs(leftSpark.y)/.11,.66));
    float glow=.46*exp(-r*r*5.1)*(1.-smoothstep(.77,1.,r));
    a=max(glow,max(sparkRight*.84,sparkLeft*.64));
    c=mix(vec3(1.,.65,.26),vec3(1.,.95,.74),exp(-r*3.)+a*.24);
  }
  if(mode==7.) {
    float shine=.10*abs(rot.x)+.11*max(0.,depth*9.);
    c=tint+vec3(shine,shine*.82,shine*.50);
    a=.72;
  }
  if(mode==4.) {a=(1.-smoothstep(.1,1.,r))*(.50+.18*sin(time*.7+depth*3.));}
  if(theme>.5) {
    if(mode==0.) {
      float frost=max(0.,c.r-.08);
      c=theme<1.5?vec3(.19,.22,.24)+frost*vec3(1.2,1.25,1.3)
                  :vec3(.07,.22,.34)+frost*vec3(.69,1.10,1.5);
    }
    if(mode==1. || mode==3.) {
      float brightness=max(c.r,max(c.g,c.b));
      c=brightness*(theme<1.5?vec3(1.,.97,.89):vec3(.72,.91,1.));
    }
  }
  gl_FragColor=vec4(c,a);
}`;
function program(gl) {
  const result=gl.createProgram();
  for(const [type,src] of [[gl.VERTEX_SHADER,vertex],[gl.FRAGMENT_SHADER,fragment]]){
    const shader=gl.createShader(type);
    gl.shaderSource(shader,src); gl.compileShader(shader);
    if(!gl.getShaderParameter(shader,gl.COMPILE_STATUS)) throw Error(gl.getShaderInfoLog(shader));
    gl.attachShader(result,shader); gl.deleteShader(shader);
  }
  gl.linkProgram(result);
  if(!gl.getProgramParameter(result,gl.LINK_STATUS)) throw Error(gl.getProgramInfoLog(result));
  return result;
}
const crown = y => 1.62 * Math.pow(Math.max(0,(2.57-y)/2.6),.96);
const frontAngle=.18, depthScale=.115, cameraTilt=.11, screenBase=.897;
const frontCos=Math.cos(frontAngle), frontSin=Math.sin(frontAngle);

function ornamentAnchor(sceneX,sceneY,sx,sy){
  const rayX=(sceneX-.5)*2/sx;
  const rayY=(screenBase-sceneY)*2/sy;
  const radius=crown(rayY)*.87;
  const z=Math.max(.06,Math.sqrt(Math.max(0,radius*radius-rayX*rayX)));
  const w=1-z*depthScale, x=rayX*w;
  return {x:x*frontCos-z*frontSin,y:rayY*w+z*cameraTilt,z:x*frontSin+z*frontCos};
}
function foliage(){
  const rand=random(140), needles=[], limbs=[], lights=[], snow=[], glints=[];
  for(let i=0;i<320;i++){
    const level=i/320, y=.03+level*2.53, angle=i*2.39996;
    const length=crown(y)*(.68+rand()*.34)*(1-.17*Math.cos(level*46));
    const lean=.12+length*.17;
    limbs.push(0,y-.12,0,.19,.12,.066,1, Math.cos(angle)*length,y+lean,Math.sin(angle)*length,.18,.16,.08,1);
    for(let j=0;j<190;j++){
      const t=.18+.82*rand(), offset=(rand()-.5)*(.13+length*.23)*(1-t*.83);
      const branch=angle+offset/(t+.22);
      const radius=length*t*(.73+.27*rand());
      const hue=.40+rand()*.65;
      const frost=rand()<.092 ? .27 : 0;
      needles.push(Math.cos(branch)*radius,y+lean*t+(rand()-.52)*(.20+length*.14)*(1-t*.50),Math.sin(branch)*radius,
        .15*hue+frost,.43*hue+frost,.30*hue+frost,(2.1+rand()*3.5)*(1-.31*level));
    }
  }
  for(let i=0;i<240;i++){
    const fraction=i/240, y=.12+fraction*2.38, a=fraction*turn*7.4+(rand()-.5)*.5;
    const radius=crown(y)*(.83+.17*rand());
    lights.push(Math.cos(a)*radius,y,Math.sin(a)*radius,1,.65+rand()*.23,.30+rand()*.18,3.5+rand()*9);
    if(i%13===0)glints.push(Math.cos(a)*radius,y+.012,Math.sin(a)*radius,1,.83,.54,12+rand()*8);
  }
  for(let i=0;i<620;i++){
    const a=rand()*turn,r=Math.sqrt(rand())*1.95;
    lights.push(Math.cos(a)*r,-.10+rand()*.017,Math.sin(a)*r,.55+rand()*.25,.47,.26,1+rand()*3);
  }
  for(let i=0;i<210;i++) snow.push((rand()-.5)*7,(rand()*4), (rand()-.5)*5,.78,.86,.81,1+rand()*3);
  for(let i=0;i<26;i++){
    const a=i/26*turn;
    limbs.push(Math.cos(a)*.083,-.13,Math.sin(a)*.083,.28,.18,.11,1, Math.cos(a)*.049,1.5,Math.sin(a)*.049,.2,.15,.08,1);
  }
  return {needles,limbs,lights,snow,glints};
}

function topperMesh(){
  const center=2.588;
  const ring=[[0,.165],[.039,.045],[.145,0],[.039,-.045],[0,-.153],[-.039,-.045],[-.145,0],[-.039,.045]];
  const faceColors=[[1.,.86,.56],[.83,.53,.21],[.98,.72,.36],[.79,.47,.16],
    [.91,.63,.32],[1.,.82,.49],[.91,.65,.32],[1.,.91,.67]];
  const mesh=[];
  for(const side of [1,-1]){
    for(let i=0;i<ring.length;i++){
      const first=ring[i], second=ring[(i+1)%ring.length];
      const color=faceColors[side===1?i:(i+3)%ring.length];
      const rim=[1.,.89,.66];
      mesh.push(0,center,side*.066,...color,1);
      for(const [x,y] of side===1?[second,first]:[first,second]){
        mesh.push(x,center+y,0,...rim,1);
      }
    }
  }
  return mesh;
}

export function createTree(canvas, overlay, open){
  const motion=matchMedia('(prefers-reduced-motion: reduce)');
  let gl, shader;
  try {gl=canvas.getContext('webgl',{alpha:true,antialias:true}); if(gl) shader=program(gl);} catch(error){console.warn(error);}
  let angle=frontAngle, target=angle, items=[], frame=0, windUntil=0, theme=0;
  let placing=false;
  let draw=()=>{};
  const refresh=()=>{if(!frame) frame=requestAnimationFrame(draw);};
  const rotate=delta=>{if(!placing){target+=delta;refresh();}};
  function setPlacing(active){
    placing=active;
    if(active){angle=target=frontAngle;refresh();}
  }
  const snow=()=>{windUntil=performance.now()+4500; refresh();};
  if(gl && shader){
    canvas.parentElement.classList.add('ready');
    gl.useProgram(shader);
    gl.enable(gl.BLEND);
    gl.blendFuncSeparate(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA,gl.ONE,gl.ONE_MINUS_SRC_ALPHA);
    gl.enable(gl.DEPTH_TEST);
    const attrs=['pos','color','size'].map(key=>gl.getAttribLocation(shader,key));
    const uniforms=Object.fromEntries(['rot','scale','pixel','mode','time','theme'].map(key=>[key,gl.getUniformLocation(shader,key)]));
    const buffer=(values,dynamic=false)=>{
      const b=gl.createBuffer();
      return {bind(data){
        gl.bindBuffer(gl.ARRAY_BUFFER,b);
        if(data)gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(data),dynamic?gl.DYNAMIC_DRAW:gl.STATIC_DRAW);
      }};
    };
    const render=(entry,count,mode,primitive=gl.POINTS)=>{
      entry.bind();
      attrs.forEach((a,i)=>{gl.enableVertexAttribArray(a);gl.vertexAttribPointer(a,i===2?1:3,gl.FLOAT,false,28,[0,12,24][i]);});
      gl.uniform1f(uniforms.mode,mode);
      gl.drawArrays(primitive,0,count);
    };
    const shape=foliage();
    const geometry=Object.fromEntries(Object.entries(shape).map(([k,v])=>{const b=buffer(v);b.bind(v);return [k,b];}));
    const star=buffer([]), glassStar=buffer([]);
    const mesh=topperMesh();
    star.bind([0,2.588,0,1,.87,.59,111]);
    glassStar.bind(mesh);
    let particles=0;
    const resize=new ResizeObserver(refresh);resize.observe(canvas);
    draw=(now)=>{
      frame=0;
      const dpr=Math.min(devicePixelRatio||1,2), width=canvas.clientWidth,height=canvas.clientHeight;
      if(!width||!height)return;
      if(canvas.width!==Math.round(width*dpr)||canvas.height!==Math.round(height*dpr)){canvas.width=Math.round(width*dpr);canvas.height=Math.round(height*dpr);}
      angle=motion.matches?target:angle+(target-angle)*.19;
      const cos=Math.cos(angle),sin=Math.sin(angle);
      const sy=.645, sx=Math.min(sy*height/width*1.04,.53);
      gl.viewport(0,0,canvas.width,canvas.height);
      gl.clearColor(0,0,0,0);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
      gl.uniform2f(uniforms.rot,cos,sin);gl.uniform2f(uniforms.scale,sx,sy);
      gl.uniform1f(uniforms.pixel,dpr*Math.min(height/545,1.4));
      gl.uniform1f(uniforms.theme,theme);
      gl.uniform1f(uniforms.time,motion.matches?0:now/1000);
      gl.depthMask(true);render(geometry.limbs,shape.limbs.length/7,5,gl.LINES);
      render(geometry.needles,shape.needles.length/7,0);
      gl.depthMask(false);gl.blendFuncSeparate(gl.SRC_ALPHA,gl.ONE,gl.ONE,gl.ONE_MINUS_SRC_ALPHA);
      render(geometry.lights,shape.lights.length/7,1);
      render(geometry.glints,shape.glints.length/7,3);
      gl.disable(gl.DEPTH_TEST);
      render(star,1,6);
      gl.blendFuncSeparate(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA,gl.ONE,gl.ONE_MINUS_SRC_ALPHA);
      gl.enable(gl.CULL_FACE);
      gl.cullFace(gl.FRONT);render(glassStar,mesh.length/7,7,gl.TRIANGLES);
      gl.cullFace(gl.BACK);render(glassStar,mesh.length/7,7,gl.TRIANGLES);
      gl.disable(gl.CULL_FACE);
      gl.enable(gl.DEPTH_TEST);
      for(const item of items){
        const {record,button}=item;
        if(record.scene_x != null && record.scene_y != null && item.anchorScale!==sx){
          Object.assign(item,ornamentAnchor(record.scene_x,record.scene_y,sx,sy));
          item.anchorScale=sx;
        }
        const {x,y,z}=item;
        const dz=z*cos-x*sin, dx=x*cos+z*sin, w=1-dz*depthScale;
        const show=dz>-.04;
        button.hidden=!show;
        positionOrnament(button,.5+.5*dx*sx/w,screenBase-.5*(y-dz*cameraTilt)*sy/w);
        button.style.zIndex=String(2+Math.round(dz*10+14));
      }
      gl.blendFuncSeparate(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA,gl.ONE,gl.ONE_MINUS_SRC_ALPHA);
      if(!motion.matches){
        particles=now<windUntil?210:95;
        gl.viewport(0,0,canvas.width,canvas.height);render(geometry.snow,particles,4);
      }
      gl.depthMask(true);
      if(!motion.matches||Math.abs(target-angle)>.001)refresh();
    };
    motion.addEventListener('change',refresh);
    canvas.addEventListener('webglcontextlost',e=>{
      e.preventDefault();cancelAnimationFrame(frame);frame=0;draw=()=>{};
      canvas.parentElement.classList.remove('ready');setItems(items.map(item=>item.record));
    });
    canvas.addEventListener('webglcontextrestored',()=>location.reload());
  }
  function setItems(records){
    overlay.replaceChildren();
    items=records.map((record,i)=>{
      const button=document.createElement('button'), [name]=palette[record.color]||palette.gold;
      button.className='orb-hit';button.setAttribute('aria-label',name+' · '+(ornamentShapes[record.shape]||ornamentShapes.sphere)+' '+(i+1));
      paintOrnament(button,record.color,record.shape,record.outline);
      button.onclick=()=>open(record);
      const a=i*2.39996+.8, y=.28+((i*19)%53)/53*1.85, r=crown(y)*.87+.03;
      if(record.scene_x != null && record.scene_y != null){
        positionOrnament(button,record.scene_x,record.scene_y);
        button.style.zIndex='32';
      }else{
        positionOrnament(button,.5+Math.cos(a)*r*.21,.87-y*.29);
      }
      overlay.append(button);
      return {record,x:Math.cos(a)*r,z:Math.sin(a)*r,y,button};
    });
    refresh();
  }
  let pointer=null;
  canvas.addEventListener('pointerdown',e=>{if(e.button!==0)return; pointer=e.clientX;canvas.setPointerCapture(e.pointerId);});
  canvas.addEventListener('pointermove',e=>{if(pointer!==null&&canvas.hasPointerCapture(e.pointerId)){rotate((e.clientX-pointer)*.012);pointer=e.clientX;}});
  canvas.addEventListener('lostpointercapture',()=>{pointer=null;});
  canvas.addEventListener('keydown',e=>{if(['ArrowLeft','ArrowRight'].includes(e.key)){e.preventDefault();rotate(e.key==='ArrowLeft'?-.35:.35);}});
  function setTheme(name){
    theme=name==='silver'?1:name==='blue'?2:0;
    canvas.closest('.scene').dataset.treeTheme=theme===1?'silver':theme===2?'blue':'green';
    refresh();
  }
  return {setItems,rotate,snow,setTheme,setPlacing};
}
