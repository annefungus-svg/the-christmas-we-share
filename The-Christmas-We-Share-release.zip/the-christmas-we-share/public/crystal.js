import {palette,ornamentShapes,paintOrnament} from './tree.js';

export function crystalMarkup() {
  return '<figure class="crystal-preview"><div class="crystal" aria-hidden="true"><div class="crystal-glass"><img alt="" hidden></div></div><figcaption></figcaption></figure>';
}

export function updateCrystal(figure, color, photo, shape, outline) {
  const [name] = palette[color] || palette.gold;
  paintOrnament(figure,color,shape,outline);
  figure.querySelector('figcaption').textContent = photo ? name+' · 记忆水晶' : name+' · '+(ornamentShapes[shape]||'水晶球');
  const image = figure.querySelector('img');
  image.hidden = !photo;
  if (photo) {
    if (image.getAttribute('src') !== photo) image.src = photo;
  } else {
    image.removeAttribute('src');
  }
}

export async function preparePhoto(file) {
  if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type) || file.size > 12 * 1024 * 1024) {
    throw Error('请选择 12 MB 以内的 JPG、PNG 或 WebP 照片。');
  }
  const bitmap = await createImageBitmap(file).catch(() => { throw Error('无法读取这张照片。'); });
  try {
    const canvas = document.createElement('canvas');
    canvas.width = canvas.height = 288;
    const context = canvas.getContext('2d', {alpha:false});
    const crop = Math.min(bitmap.width, bitmap.height);
    context.fillStyle = '#16231f';
    context.fillRect(0, 0, 288, 288);
    context.drawImage(bitmap, (bitmap.width-crop)/2, (bitmap.height-crop)/2, crop, crop, 0, 0, 288, 288);
    for (const quality of [.82, .65, .46]) {
      const photo = canvas.toDataURL('image/jpeg', quality);
      if (photo.length <= 90000) return photo;
    }
    throw Error('这张照片压缩后仍过大，请换一张。');
  } finally {
    bitmap.close();
  }
}
