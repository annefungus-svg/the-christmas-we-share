const base='https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.21';
const model='https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task';
const distance=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y,a.z-b.z);

const tips=[8,12,16,20];
const palmSize=hand=>distance(hand[0],hand[9]);
const extended=(hand,tip)=>distance(hand[tip],hand[0])>distance(hand[tip-2],hand[0])*1.14;
export function createGestureTracker(actions){
  let previousX, widest=0, wideAt=0, pose='', poseAt=0, fired=false, snowAt=-Infinity;
  return (hands,now)=>{
    const valid=hands.filter(hand=>palmSize(hand)>.025);
    const [hand,other]=valid;
    let next='';
    if(other){
      const scale=(palmSize(hand)+palmSize(other))/2;
      const open=valid.every(h=>tips.every(tip=>extended(h,tip)));
      const gap=distance(hand[9],other[9])/scale;
      const heart=distance(hand[8],other[8])/scale<.44 &&
        distance(hand[4],other[4])/scale<.48 &&
        Math.abs((hand[8].y+other[8].y-hand[4].y-other[4].y)/2)>scale*.28;
      if(heart){next='heart';widest=0;}
      else if(open){
        if(now-wideAt>2200)widest=0;
        if(gap>2.2&&gap>=widest){widest=gap;wideAt=now;}
        if(widest>2.2&&gap<widest*.58&&now-snowAt>2200){
          actions.snow();snowAt=now;widest=0;
        }
      }
      previousX=undefined;
    }else if(hand){
      widest=0;
      const scale=palmSize(hand);
      const folded=tips.every(tip=>!extended(hand,tip));
      const thumbUp=hand[3].y-hand[4].y>scale*.22&&hand[2].y-hand[4].y>scale*.48;
      const pinch=distance(hand[4],hand[8])/scale;
      const fingerHeart=pinch<.25&&[12,16,20].every(tip=>!extended(hand,tip))
        && hand[6].y-hand[8].y>scale*.13;
      if(folded&&thumbUp)next='stars';
      else if(fingerHeart)next='heart';
      else if(pinch<.23)next='favorite';
      const x=1-hand[9].x;
      if(!next&&tips.every(tip=>extended(hand,tip))&&previousX!==undefined){
        const delta=x-previousX;
        if(Math.abs(delta)>.006&&Math.abs(delta)<.18)actions.rotate(delta*5);
      }
      previousX=next?undefined:x;
    }else{
      widest=0;previousX=undefined;
    }
    if(next!==pose){pose=next;poseAt=now;fired=false;}
    if(pose&&!fired&&now-poseAt>=240){actions[pose]();fired=true;}
  };
}

export async function startGestures(video,actions){
  if(!navigator.mediaDevices?.getUserMedia)throw Error('Camera unavailable');
  const {FilesetResolver,HandLandmarker}=await import(base+'/vision_bundle.mjs');
  const files=await FilesetResolver.forVisionTasks(base+'/wasm');
  const detector=await HandLandmarker.createFromOptions(files,{baseOptions:{modelAssetPath:model,delegate:'CPU'},runningMode:'VIDEO',numHands:2});
  let stream, raf=0;
  function stop(){
    cancelAnimationFrame(raf);stream?.getTracks().forEach(track=>track.stop());
    video.pause();video.srcObject=null;detector.close();
  }
  try{
    stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:'user',width:{ideal:480},height:{ideal:360}},audio:false});
    video.srcObject=stream;await video.play();
  }catch(error){stop();throw error;}
  const track=createGestureTracker(actions);
  let lastFrame=-1, lastTime=0;
  function frame(now){
    raf=requestAnimationFrame(frame);
    if(now-lastTime<66||video.readyState<2||video.currentTime===lastFrame)return;
    lastFrame=video.currentTime;lastTime=now;
    track(detector.detectForVideo(video,now).landmarks,now);
  }
  raf=requestAnimationFrame(frame);
  return stop;
}
