const base='https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.21';
const model='https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task';
const distance=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y,a.z-b.z);

const tips=[8,12,16,20];
const screenDistance=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
const palmSize=hand=>distance(hand[0],hand[9]);
const extended=(hand,tip)=>distance(hand[tip],hand[0])>distance(hand[tip-2],hand[0])*1.14;
export function createGestureTracker(actions){
  let pose='', poseAt=0, seenAt=-Infinity, emittedAt=-Infinity, fired=false;
  return (hands,now)=>{
    const [hand,other]=hands.filter(hand=>palmSize(hand)>.014);
    let next='';
    if(hand){
      const scale=palmSize(hand);
      const open=tips.filter(tip=>extended(hand,tip)).length;
      const thumbUp=hand[2].y-hand[4].y>scale*.24 && distance(hand[4],hand[5])>scale*.55;
      const pinch=screenDistance(hand[4],hand[8])<scale*.40;
      const twoHandHeart=other && screenDistance(hand[8],other[8])<scale*.74 &&
        screenDistance(hand[4],other[4])<scale*.78;
      if(twoHandHeart)next='heart';
      else if(open<=1&&thumbUp&&!pinch)next='stars';
      else if(open<=2&&pinch)next='heart';
      else if(open>=4)next='snow';
    }
    if(next){
      if(next!==pose||now-seenAt>210){pose=next;poseAt=now;fired=false;}
      seenAt=now;
      if(!fired&&now-poseAt>=95&&now-emittedAt>=650){
        actions[pose]();fired=true;emittedAt=now;
      }
    }else if(now-seenAt>210){
      pose='';fired=false;
    }
  };
}

export async function startGestures(video,actions){
  if(!navigator.mediaDevices?.getUserMedia)throw Error('Camera unavailable');
  const {FilesetResolver,HandLandmarker}=await import(base+'/vision_bundle.mjs');
  const files=await FilesetResolver.forVisionTasks(base+'/wasm');
  const detector=await HandLandmarker.createFromOptions(files,{baseOptions:{modelAssetPath:model,delegate:'CPU'},runningMode:'VIDEO',numHands:2,minHandDetectionConfidence:.42,minHandPresenceConfidence:.42,minTrackingConfidence:.38});
  let stream, raf=0;
  function stop(){
    cancelAnimationFrame(raf);stream?.getTracks().forEach(track=>track.stop());
    video.pause();video.srcObject=null;detector.close();
  }
  try{
    stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:'user',width:{ideal:480},height:{ideal:360}},audio:false});
    video.srcObject=stream;await video.play();
  }catch(error){stop();throw error;}
  const track=createGestureTracker(actions);
  let lastFrame=-1, lastTime=0;
  function frame(now){
    raf=requestAnimationFrame(frame);
    if(now-lastTime<40||video.readyState<2||video.currentTime===lastFrame)return;
    lastFrame=video.currentTime;lastTime=now;
    track(detector.detectForVideo(video,now).landmarks,now);
  }
  raf=requestAnimationFrame(frame);
  return stop;
}
