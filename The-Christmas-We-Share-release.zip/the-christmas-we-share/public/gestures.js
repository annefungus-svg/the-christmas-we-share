const base='/mediapipe';
const model=base+'/hand_landmarker.task';
const distance=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y,a.z-b.z);

const tips=[8,12,16,20];
const screenDistance=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
const palmSize=hand=>distance(hand[0],hand[9]);
const extended=(hand,tip)=>distance(hand[tip],hand[0])>distance(hand[tip-2],hand[0])*1.14;
export function createGestureTracker(actions){
  let pose='', poseAt=0, seenAt=-Infinity, emittedAt=-Infinity, fired=false;
  return (hands,now)=>{
    const [hand,other]=hands.filter(hand=>palmSize(hand)>.014);
    let next='';
    if(hand){
      const scale=palmSize(hand);
      const open=tips.filter(tip=>extended(hand,tip)).length;
      const thumbUp=hand[2].y-hand[4].y>scale*.24 && distance(hand[4],hand[5])>scale*.55;
      const pinch=screenDistance(hand[4],hand[8])<scale*.40;
      const twoHandHeart=other && screenDistance(hand[8],other[8])<scale*.74 &&
        screenDistance(hand[4],other[4])<scale*.78;
      if(twoHandHeart)next='heart';
      else if(open<=1&&thumbUp&&!pinch)next='stars';
      else if(open<=2&&pinch)next='heart';
      else if(open>=4)next='snow';
    }
    if(next){
      if(next!==pose||now-seenAt>210){pose=next;poseAt=now;fired=false;}
      seenAt=now;
      if(!fired&&now-poseAt>=95&&now-emittedAt>=650){
        actions[pose]();fired=true;emittedAt=now;
      }
    }else if(now-seenAt>210){
      pose='';fired=false;
    }
  };
}

function withDeadline(promise,signal,ms,message){
  return new Promise((resolve,reject)=>{
    const aborted=()=>finish(reject,signal.reason);
    const timer=setTimeout(()=>finish(reject,Error(message)),ms);
    function finish(callback,value){
      clearTimeout(timer);
      signal.removeEventListener('abort',aborted);
      callback(value);
    }
    promise.then(value=>finish(resolve,value),error=>finish(reject,error));
    if(signal.aborted)aborted();
    else signal.addEventListener('abort',aborted,{once:true});
  });
}

async function createDetector(){
  const {FilesetResolver,HandLandmarker}=await import(base+'/vision_bundle.mjs');
  const files=await FilesetResolver.forVisionTasks(base+'/wasm');
  return HandLandmarker.createFromOptions(files,{baseOptions:{modelAssetPath:model,delegate:'CPU'},runningMode:'VIDEO',numHands:2,minHandDetectionConfidence:.42,minHandPresenceConfidence:.42,minTrackingConfidence:.38});
}

export async function startGestures(video,actions,{signal,onLoading,onError}){
  if(!navigator.mediaDevices?.getUserMedia)throw Error('当前浏览器无法打开摄像头。请用手机系统浏览器打开链接。');
  let stream, detector, raf=0, stopped=false;
  function stop(){
    if(stopped)return;
    stopped=true;
    cancelAnimationFrame(raf);
    stream?.getTracks().forEach(track=>track.stop());
    if(stream&&video.srcObject===stream){
      video.pause();video.srcObject=null;video.hidden=true;
    }
    detector?.close();
    signal.removeEventListener('abort',stop);
  }
  signal.addEventListener('abort',stop,{once:true});
  const fail=message=>{stop();onError(message);};
  try{
    // Start the permission request directly from the tap, before downloading any model files.
    const camera=navigator.mediaDevices.getUserMedia({video:{facingMode:'user',width:{ideal:480},height:{ideal:360}},audio:false});
    camera.then(result=>{if(stopped)result.getTracks().forEach(track=>track.stop());},()=>{});
    stream=await withDeadline(camera,signal,24000,'没有收到摄像头权限回应。请检查浏览器的相机权限，或用系统浏览器打开。');
    if(signal.aborted)throw signal.reason;
    for(const track of stream.getVideoTracks())track.addEventListener('ended',()=>fail('摄像头已断开，可以再点一次「手势」。'),{once:true});
    video.hidden=false;
    video.srcObject=stream;
    await withDeadline(video.play(),signal,8000,'摄像头已授权，但画面未启动。请尝试在系统浏览器中打开。');
    onLoading();
    const modelTask=createDetector();
    modelTask.then(result=>{if(stopped)result.close();},()=>{});
    detector=await withDeadline(modelTask,signal,45000,'手势模型下载超时。可以重试，也可以直接拖动和点击树。');
    if(signal.aborted)throw signal.reason;
  }catch(error){
    stop();
    if(error.name==='NotAllowedError'||error.name==='SecurityError')throw Error('摄像头未获授权。请在浏览器的网站权限中允许相机，再点一次「手势」。');
    if(error.name==='NotFoundError'||error.name==='NotReadableError')throw Error('摄像头不可用，可能正在被其他应用使用。');
    throw error;
  }
  const track=createGestureTracker(actions);
  let lastFrame=-1, lastTime=0;
  function frame(now){
    if(stopped)return;
    raf=requestAnimationFrame(frame);
    if(now-lastTime<40||video.readyState<2||video.currentTime===lastFrame)return;
    lastFrame=video.currentTime;lastTime=now;
    try{track(detector.detectForVideo(video,now).landmarks,now);}
    catch{fail('手势识别中断了，可以再点一次「手势」。');}
  }
  raf=requestAnimationFrame(frame);
  return stop;
}
