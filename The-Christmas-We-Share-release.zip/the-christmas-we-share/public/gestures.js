const base='/mediapipe';
const model=base+'/hand_landmarker.task';
const distance=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y,a.z-b.z);

const tips=[8,12,16,20];
const screenDistance=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
const palmSize=hand=>distance(hand[0],hand[9]);
const extended=(hand,tip)=>distance(hand[tip],hand[0])>distance(hand[tip-2],hand[0])*1.14;
export function createGestureTracker(actions){
  let pose='', poseAt=0, seenAt=-Infinity, emittedAt=-Infinity, fired=false;
  return (hands,now)=>{
    const [hand,other]=hands.filter(hand=>palmSize(hand)>.014);
    let next='';
    if(hand){
      const scale=palmSize(hand);
      const open=tips.filter(tip=>extended(hand,tip)).length;
      const thumbUp=hand[2].y-hand[4].y>scale*.24 && distance(hand[4],hand[5])>scale*.55;
      const pinch=screenDistance(hand[4],hand[8])<scale*.40;
      const twoHandHeart=other && screenDistance(hand[8],other[8])<scale*.74 &&
        screenDistance(hand[4],other[4])<scale*.78;
      if(twoHandHeart)next='heart';
      else if(open<=1&&thumbUp&&!pinch)next='stars';
      else if(open<=2&&pinch)next='heart';
      else if(open>=4)next='snow';
    }
    if(next){
      if(next!==pose||now-seenAt>210){pose=next;poseAt=now;fired=false;}
      seenAt=now;
      if(!fired&&now-poseAt>=95&&now-emittedAt>=650){
        actions[pose]();fired=true;emittedAt=now;
      }
    }else if(now-seenAt>210){
      pose='';fired=false;
    }
  };
}

function withDeadline(promise,signal,ms,message){
  return new Promise((resolve,reject)=>{
    const aborted=()=>finish(reject,signal.reason);
    const timer=setTimeout(()=>finish(reject,Error(message)),ms);
    function finish(callback,value){
      clearTimeout(timer);
      signal.removeEventListener('abort',aborted);
      callback(value);
    }
    promise.then(value=>finish(resolve,value),error=>finish(reject,error));
    if(signal.aborted)aborted();
    else signal.addEventListener('abort',aborted,{once:true});
  });
}

async function fetchGestureAsset(url,signal,onBytes){
  const download=new AbortController();
  const cancel=()=>download.abort(signal.reason);
  const stalled=()=>download.abort(Error('手势文件下载已停滞。请检查网络后再试。'));
  let timer=setTimeout(stalled,35000);
  if(signal.aborted)cancel();
  else signal.addEventListener('abort',cancel,{once:true});
  try{
    const response=await fetch(url,{signal:download.signal,cache:'force-cache'});
    if(!response.ok)throw Error('手势文件暂时无法下载。请刷新后再试。');
    if(!response.body)return new Uint8Array(await response.arrayBuffer());
    const reader=response.body.getReader(), chunks=[];
    let size=0;
    while(true){
      const {value,done}=await reader.read();
      if(done)break;
      chunks.push(value);size+=value.byteLength;
      onBytes(size);
      clearTimeout(timer);timer=setTimeout(stalled,35000);
    }
    const bytes=new Uint8Array(size);
    let offset=0;
    for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.byteLength;}
    return bytes;
  }catch(error){
    if(download.signal.aborted)throw download.signal.reason;
    if(error instanceof TypeError)throw Error('手势文件下载中断。请检查网络后再试。');
    throw error;
  }finally{
    clearTimeout(timer);
    signal.removeEventListener('abort',cancel);
  }
}

async function createDetector(signal,onLoading){
  const pending=new AbortController();
  const cancel=()=>pending.abort(signal.reason);
  signal.addEventListener('abort',cancel,{once:true});
  if(signal.aborted)cancel();

  let binaryUrl;
  try{
    const library=import(base+'/vision_bundle.mjs');
    const packed=typeof DecompressionStream==='function';
    const modelSize=packed?5813795:7819105;
    let wasmSize=9574032, modelLoaded=0, wasmLoaded=0, reported=-1;
    const progress=()=>{
      const percent=Math.min(99,Math.floor(100*(modelLoaded+wasmLoaded)/(modelSize+wasmSize)));
      if(percent!==reported){reported=percent;onLoading('正在下载手势文件… '+percent+'%');}
    };
    progress();
    const modelTask=fetchGestureAsset(model+(packed?'.gz':''),pending.signal,bytes=>{modelLoaded=bytes;progress();});
    const wasmTask=(async()=>{
      const {FilesetResolver,HandLandmarker}=await withDeadline(library,pending.signal,30000,'手势组件加载超时。请检查网络后再试。');
      const files=await FilesetResolver.forVisionTasks(base+'/wasm');
      if(files.wasmBinaryPath.includes('nosimd'))wasmSize=9448638;
      const bytes=await fetchGestureAsset(files.wasmBinaryPath,pending.signal,downloaded=>{wasmLoaded=downloaded;progress();});
      return {files,HandLandmarker,bytes};
    })();
    const [modelBytes,{files,HandLandmarker,bytes}]=await Promise.all([modelTask,wasmTask]);
    if(signal.aborted)throw signal.reason;
    onLoading('下载完成，正在启动手势识别…');
    const unpacked=packed&&modelBytes[0]===0x1f&&modelBytes[1]===0x8b
      ? new Uint8Array(await new Response(new Blob([modelBytes]).stream().pipeThrough(new DecompressionStream('gzip'))).arrayBuffer())
      : modelBytes;
    if(signal.aborted)throw signal.reason;
    binaryUrl=URL.createObjectURL(new Blob([bytes],{type:'application/wasm'}));
    const setup=HandLandmarker.createFromOptions({...files,wasmBinaryPath:binaryUrl},{
      baseOptions:{modelAssetBuffer:unpacked,delegate:'CPU'},runningMode:'VIDEO',numHands:2,
      minHandDetectionConfidence:.42,minHandPresenceConfidence:.42,minTrackingConfidence:.38
    });
    try{
      return await withDeadline(setup,signal,45000,'手势文件已下载，但识别启动超时。请重试。');
    }catch(error){
      setup.then(result=>result.close(),()=>{});
      throw error;
    }
  }finally{
    pending.abort();
    signal.removeEventListener('abort',cancel);
    if(binaryUrl)URL.revokeObjectURL(binaryUrl);
  }
}

export async function startGestures(video,actions,{signal,onLoading,onError}){
  if(!navigator.mediaDevices?.getUserMedia)throw Error('当前浏览器无法打开摄像头。请用手机系统浏览器打开链接。');
  let stream, detector, raf=0, stopped=false;
  function stop(){
    if(stopped)return;
    stopped=true;
    cancelAnimationFrame(raf);
    stream?.getTracks().forEach(track=>track.stop());
    if(stream&&video.srcObject===stream){
      video.pause();video.srcObject=null;video.hidden=true;
    }
    detector?.close();
    signal.removeEventListener('abort',stop);
  }
  signal.addEventListener('abort',stop,{once:true});
  const fail=message=>{stop();onError(message);};
  try{
    // Start the permission request directly from the tap, before downloading any model files.
    const camera=navigator.mediaDevices.getUserMedia({video:{facingMode:'user',width:{ideal:480},height:{ideal:360}},audio:false});
    camera.then(result=>{if(stopped)result.getTracks().forEach(track=>track.stop());},()=>{});
    stream=await withDeadline(camera,signal,24000,'没有收到摄像头权限回应。请检查浏览器的相机权限，或用系统浏览器打开。');
    if(signal.aborted)throw signal.reason;
    for(const track of stream.getVideoTracks())track.addEventListener('ended',()=>fail('摄像头已断开，可以再点一次「手势」。'),{once:true});
    video.hidden=false;
    video.srcObject=stream;
    await withDeadline(video.play(),signal,8000,'摄像头已授权，但画面未启动。请尝试在系统浏览器中打开。');
    detector=await createDetector(signal,onLoading);
    if(stopped){detector.close();throw signal.reason;}
    if(signal.aborted)throw signal.reason;
  }catch(error){
    stop();
    if(error.name==='NotAllowedError'||error.name==='SecurityError')throw Error('摄像头未获授权。请在浏览器的网站权限中允许相机，再点一次「手势」。');
    if(error.name==='NotFoundError'||error.name==='NotReadableError')throw Error('摄像头不可用，可能正在被其他应用使用。');
    throw error;
  }
  const track=createGestureTracker(actions);
  let lastFrame=-1, lastTime=0;
  function frame(now){
    if(stopped)return;
    raf=requestAnimationFrame(frame);
    if(now-lastTime<40||video.readyState<2||video.currentTime===lastFrame)return;
    lastFrame=video.currentTime;lastTime=now;
    try{track(detector.detectForVideo(video,now).landmarks,now);}
    catch{fail('手势识别中断了，可以再点一次「手势」。');}
  }
  raf=requestAnimationFrame(frame);
  return stop;
}
