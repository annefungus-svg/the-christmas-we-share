const base='https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.21';
const model='https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task';
const distance=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y,a.z-b.z);

export async function startGestures(video,actions){
  if(!navigator.mediaDevices?.getUserMedia)throw Error('Camera unavailable');
  const {FilesetResolver,HandLandmarker}=await import(base+'/vision_bundle.mjs');
  const files=await FilesetResolver.forVisionTasks(base+'/wasm');
  const detector=await HandLandmarker.createFromOptions(files,{baseOptions:{modelAssetPath:model,delegate:'CPU'},runningMode:'VIDEO',numHands:1});
  let stream, raf=0;
  function stop(){
    cancelAnimationFrame(raf);stream?.getTracks().forEach(track=>track.stop());
    video.pause();video.srcObject=null;detector.close();
  }
  try{
    stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:'user',width:{ideal:480},height:{ideal:360}},audio:false});
    video.srcObject=stream;await video.play();
  }catch(error){stop();throw error;}
  let lastFrame=-1, lastTime=0, previousX, openSince=0, snowAt=-5000, pinned=false;
  function frame(now){
    raf=requestAnimationFrame(frame);
    if(now-lastTime<66||video.readyState<2||video.currentTime===lastFrame)return;
    lastFrame=video.currentTime;lastTime=now;
    const hand=detector.detectForVideo(video,now).landmarks[0];
    if(!hand){previousX=undefined;openSince=0;pinned=false;return;}
    const palm=distance(hand[0],hand[9]);
    if(palm<.02)return;
    const x=1-hand[9].x;
    const spread=[8,12,16,20].every(tip=>distance(hand[tip],hand[0])>distance(hand[tip-2],hand[0])*1.15);
    if(previousX!==undefined&&Math.abs(x-previousX)>.006&&Math.abs(x-previousX)<.18)actions.rotate((x-previousX)*5);
    previousX=x;
    if(spread){
      if(!openSince)openSince=now;
      if(now-openSince>450&&now-snowAt>5000){actions.snow();snowAt=now;}
    }else openSince=0;
    const pinch=distance(hand[4],hand[8])/palm;
    if(pinch<.23&&!pinned){pinned=true;actions.favorite();}
    if(pinch>.40)pinned=false;
  }
  raf=requestAnimationFrame(frame);
  return stop;
}
