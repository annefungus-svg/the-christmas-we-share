import {createServer} from 'node:http';
import {Readable} from 'node:stream';
import {readFile} from 'node:fs/promises';
import {handle} from './api/tree.mjs';

try{process.loadEnvFile('.env.local');}catch(error){if(error.code!=='ENOENT')throw error;}
const port=Number(process.env.PORT||3000);
const hosted=process.env.RENDER==='true';
const origin=hosted?new URL(process.env.RENDER_EXTERNAL_URL).origin:'http://localhost:'+port;
const settings=hosted?{...process.env,APP_ORIGIN:origin}:process.env;
const headers={'X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer',
  'Permissions-Policy':'camera=(self), microphone=(), geolocation=()','X-Frame-Options':'DENY'};
const files={'/':'index.html','/index.html':'index.html','/style.css':'style.css','/app.js':'app.js','/tree.js':'tree.js','/crystal.js':'crystal.js','/overture.js':'overture.js','/gestures.js':'gestures.js','/winter.wav':'winter.wav'};
for(const asset of ['vision_bundle.mjs','hand_landmarker.task','hand_landmarker.task.gz','wasm/vision_wasm_internal.js','wasm/vision_wasm_internal.wasm',
  'wasm/vision_wasm_nosimd_internal.js','wasm/vision_wasm_nosimd_internal.wasm']){
  files['/mediapipe/'+asset]='mediapipe/'+asset;
}
const types={gz:'application/gzip',mjs:'text/javascript; charset=utf-8',wasm:'application/wasm',task:'application/octet-stream',html:'text/html; charset=utf-8',css:'text/css; charset=utf-8',js:'text/javascript; charset=utf-8',wav:'audio/wav'};
createServer(async(req,res)=>{
  try{
    for(const [name,value] of Object.entries(headers))res.setHeader(name,value);
    const url=new URL(req.url,origin);
    if(url.pathname==='/api/tree'){
      const body=['GET','HEAD'].includes(req.method)?undefined:Readable.toWeb(req);
      const reply=await handle(new Request(url,{method:req.method,headers:req.headers,body,duplex:'half'}),{settings,platform:hosted?'render':'local'});
      res.writeHead(reply.status,Object.fromEntries(reply.headers));
      res.end(Buffer.from(await reply.arrayBuffer()));return;
    }
    const file=Object.hasOwn(files,url.pathname)?files[url.pathname]:null;
    if(!file||!['GET','HEAD'].includes(req.method)){res.writeHead(404).end();return;}
    const bytes=await readFile(new URL('./public/'+file,import.meta.url));
    res.writeHead(200,{'Content-Type':types[file.split('.').at(-1)],'Content-Length':bytes.length,'Cache-Control':'no-cache'});
    res.end(req.method==='HEAD'?undefined:bytes);
  }catch{res.writeHead(500).end();}
}).listen(port,hosted?'0.0.0.0':'127.0.0.1',()=>console.log(origin));
