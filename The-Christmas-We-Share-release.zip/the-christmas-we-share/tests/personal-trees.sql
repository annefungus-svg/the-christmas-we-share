-- Run after all migrations as postgres on a test Supabase project.
begin;
insert into auth.users(id,email,raw_app_meta_data)
values
 ('428dbbd9-7997-4164-97de-96fd12b4f207','winter-rls-a@accounts.winter-tree.invalid','{"winter_username":"winter-rls-a"}'),
 ('60f9354c-0dba-43f8-98c5-957dddaec514','winter-rls-b@accounts.winter-tree.invalid','{"winter_username":"winter-rls-b"}');

set local role service_role;
select public.winter_add_gift('{"tree_slug":"winter-rls-a","color":"ice","sender":"A","message":"Private A","song":"","url":"","scene_x":0.52,"scene_y":0.6,"scene_angle":3.14}');
select public.winter_add_gift('{"tree_slug":"winter-rls-b","color":"rose","sender":"B","message":"Private B","song":"","url":""}');
reset role;

set local role anon;
do $$
begin
  if (select count(*) from public.winter_trees where slug in ('winter-rls-a','winter-rls-b'))<>2
    then raise exception 'Missing public tree'; end if;
  if not exists(select 1 from public.winter_ornaments where tree_slug='winter-rls-a' and scene_angle=3.14)
    then raise exception 'Placement angle did not round-trip'; end if;
  begin
    perform owner_id from public.winter_trees;
    raise exception 'Guest could see owner IDs';
  exception when insufficient_privilege then null;
  end;
end;
$$;
reset role;

select set_config('request.jwt.claim.sub','428dbbd9-7997-4164-97de-96fd12b4f207',true);
set local role authenticated;
do $$
begin
  if not exists(select 1 from public.winter_gifts where message='Private A')
    then raise exception 'Tree owner could not read own gift'; end if;
  if exists(select 1 from public.winter_gifts where message='Private B')
    then raise exception 'Gift leaked across trees'; end if;
  delete from public.winter_ornaments where tree_slug='winter-rls-b';
  if found then raise exception 'Cross-tree delete succeeded'; end if;
end;
$$;
rollback;
