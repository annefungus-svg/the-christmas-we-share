import {test} from 'node:test';
import assert from 'node:assert/strict';
import {handle} from '../api/tree.mjs';
import {gift} from '../lib/validation.mjs';

const origin='https://winter.example';
const owner='cf408da6-22c9-4fe2-92b9-5f63d4520c8a';
const input={color:'ice',sender:' Friend ',message:' Merry Christmas! ',song:'Winter',url:''};
const request=(action,body,headers={})=>new Request(origin+'/api/tree?action='+action,{
  method:body===undefined?'GET':'POST',
  headers:{origin,'content-type':'application/json',...headers},
  body:body===undefined?undefined:JSON.stringify(body)
});
const json=(value,status=200)=>Response.json(value,{status});

test('validates color, private text, and HTTPS URL',()=>{
  assert.equal(gift(input).sender,'Friend');
  for(const sender of [undefined,'','  '])assert.throws(()=>gift({...input,sender}),/署名/);
  assert.equal(gift(input).photo,'');
  assert.equal(gift({...input,shape:'star',scene_x:.2,scene_y:.9}).scene_y,.9);
  assert.throws(()=>gift({...input,scene_x:1.2,scene_y:.6}),/位置/);
  assert.equal(gift({...input,scene_x:.2,scene_y:.6,scene_angle:Math.PI}).scene_angle,Math.PI);
  assert.throws(()=>gift({...input,scene_angle:Math.PI}),/角度/);
  assert.throws(()=>gift({...input,scene_x:.2,scene_y:.6,scene_angle:2*Math.PI}),/角度/);
  assert.throws(()=>gift({...input,shape:'unknown'}),/造型/);
  const outline=[[15,10],[85,10],[85,90],[15,90]];
  assert.deepEqual(gift({...input,shape:'custom',outline}).outline,outline);
  assert.throws(()=>gift({...input,shape:'custom',outline:[[15,10],[85,10],[85,90],[105,90]]}),/轮廓/);
  assert.throws(()=>gift({...input,photo:'data:image/svg+xml;base64,PHN2Zz4='}),/照片格式/);
  assert.throws(()=>gift({...input,photo:'data:image/jpeg;base64,PHN2Zz4='}),/照片格式/);
  for(const variant of [{color:'other'},{message:' '},{message:'a'.repeat(601)},{url:'javascript:alert(0)'},{url:'https://user@example.com'}]){
    assert.throws(()=>gift({...input,...variant}));
  }
  assert.equal(gift({...input,url:'https://EXAMPLE.com'}).url,'https://example.com/');
  const {song,url,...messageOnly}=input;
  assert.deepEqual(gift(messageOnly),gift({...messageOnly,song:'',url:''}));
});

test('missing credentials keep production submission disabled',async()=>{
  delete process.env.SUPABASE_URL;
  const result=await handle(request('gift',input));
  assert.equal(result.status,503);
  assert.equal((await result.json()).demo,undefined);
  const local=await handle(new Request('http://localhost:3000/api/tree'));
  assert.equal(local.status,503);
  assert.equal((await local.json()).demo,true);
});

test('API permission, submission, and session boundaries',async t=>{
  Object.assign(process.env,{APP_ORIGIN:origin,SUPABASE_URL:'https://database.example',SUPABASE_ANON_KEY:'public-key',
    SUPABASE_SERVICE_ROLE_KEY:'secret-key',OWNER_USER_ID:owner,RATE_LIMIT_SECRET:'a'.repeat(32)});
  let calls=[], rate=true, authUser=owner, personal=null, claimed=false;
  t.mock.method(globalThis,'fetch',async (url,options)=>{
    const path=new URL(url).pathname;
    calls.push({url,options,path});
    if(path.endsWith('winter_take_rate'))return json(rate);
    if(path.endsWith('winter_add_gift'))return new Response(null,{status:204});
    if(path.endsWith('winter_ornaments'))return json([{id:owner,color:'ice'}]);
    if(path.endsWith('winter_trees'))return json(claimed?[{slug:'snow-night'}]:[]);
    if(path.endsWith('/admin/users')){claimed=true;personal='snow-night';return json({id:authUser});}
    if(path.endsWith('/token'))return json({access_token:'owner.token',expires_in:5400,user:{id:authUser,email_confirmed_at:'now',app_metadata:{winter_username:personal}}});
    if(path.endsWith('/user'))return json({id:authUser,email_confirmed_at:'now',app_metadata:{winter_username:personal}});
    if(path.endsWith('winter_gifts'))return json([{id:owner,message:'private',favorite:false}]);
    throw Error('Unexpected upstream request');
  });
  let result=await handle(request('public'));
  assert.deepEqual(await result.json(),{items:[{id:owner,color:'ice'}]});
  assert.match(calls.at(-1).url,/select=id,color,shape,scene_x,scene_y,outline,scene_angle&/);
  assert.doesNotMatch(calls.at(-1).url,/photo/);
  assert.equal(calls.at(-1).options.headers.apikey,'public-key');
  assert.equal(result.headers.get('cache-control'),'no-store');
  calls=[];
  assert.equal((await handle(request('list'))).status,401);
  assert.equal((await handle(request('gift',input,{origin:'https://else.example'}))).status,403);
  assert.equal((await handle(request('gift',{message:'a'.repeat(96000)}))).status,400);
  assert.equal(calls.length,0);
  rate=false;
  assert.equal((await handle(request('gift',input))).status,429);
  assert.equal(calls.length,1);
  rate=true;
  assert.equal((await handle(request('gift',input))).status,201);
  assert.equal(calls.at(-1).options.headers.apikey,'secret-key');
  assert.deepEqual(JSON.parse(calls.at(-1).options.body).payload,gift(input));
  const auth={email:'owner@example.com',password:'example-only'};
  authUser='visitor';
  assert.equal((await handle(request('login',auth))).status,401);
  assert.equal((await handle(request('list',undefined,{cookie:'winter_owner=owner.token'}))).status,401);
  authUser=owner;
  result=await handle(request('login',auth));
  assert.equal(result.status,200);
  assert.match(result.headers.get('set-cookie'),/HttpOnly; SameSite=Strict; Path=\/api; Max-Age=3600; Secure/);
  result=await handle(request('list&id='+owner,undefined,{cookie:'winter_owner=owner.token'}));
  assert.equal(result.status,200);
  assert.match(calls.at(-1).url,/id=eq\./);
  assert.match(calls.at(-1).url,/photo,winter_ornaments/);
  assert.equal(calls.at(-1).options.headers.Authorization,'Bearer owner.token');
  assert.equal(calls.at(-1).options.headers.apikey,'public-key');
  result=await handle(request('favorite',{id:owner,favorite:true},{cookie:'winter_owner=owner.token'}));
  assert.equal(result.status,200);
  assert.equal(calls.at(-1).options.method,'PATCH');
  assert.equal((await handle(request('delete',{id:owner}))).status,401);
  assert.equal((await handle(request('delete',{id:owner},{cookie:'winter_owner=owner.token'}))).status,200);
  assert.equal(calls.at(-1).options.method,'DELETE');
  const creds={username:'Snow-Night',password:'winter-special'};
  assert.equal((await handle(request('public&tree=snow-night'))).status,404);
  authUser='friend';
  result=await handle(request('signup',creds));
  assert.equal(result.status,200);
  assert.deepEqual(await result.json(),{ok:true,tree:'snow-night'});
  assert.equal((await handle(request('signup',creds))).status,409);
  const guestCookie={cookie:'winter_owner=owner.token'};
  assert.equal((await handle(request('list&tree=not-my-tree',undefined,guestCookie))).status,401);
  assert.equal((await handle(request('list',undefined,guestCookie))).status,401);
  assert.equal((await handle(request('list&tree=snow-night',undefined,guestCookie))).status,200);
  assert.match(calls.at(-1).url,/tree_slug=eq.snow-night/);
  assert.equal((await handle(request('gift&tree=snow-night',input))).status,201);
  assert.equal(JSON.parse(calls.at(-1).options.body).payload.tree_slug,'snow-night');

});

test('Cloudflare routes assets and keeps a missing-config Worker out of demo mode',async()=>{
  const {default:worker}=await import('../worker.mjs');
  const request=new Request('https://winter.example/');
  const env={ASSETS:{fetch:async assetRequest=>{
    assert.equal(assetRequest,request);
    return new Response('tree');
  }}};
  assert.equal(await (await worker.fetch(request,env)).text(),'tree');
  const result=await worker.fetch(new Request('http://localhost:3000/api/tree'),env);
  assert.equal(result.status,503);
  assert.equal((await result.json()).demo,undefined);
});
