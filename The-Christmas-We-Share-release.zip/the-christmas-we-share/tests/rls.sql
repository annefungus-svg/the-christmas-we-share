-- Run as postgres on a migrated development Supabase project with a registered owner.
-- All fixtures and modifications are rolled back.
begin;
do $$
declare owner_id uuid;
begin
  select user_id into owner_id from public.winter_owner;
  if owner_id is null then raise exception 'Set winter_owner first'; end if;
  perform set_config('winter.test_owner',owner_id::text,true);
end;
$$;
set local role service_role;
select public.winter_add_gift('{"color":"ice","sender":"RLS test","song":"","message":"Secret test","url":"","shape":"custom","scene_x":0.25,"scene_y":0.65,"outline":[[10,10],[90,10],[90,90],[10,90]]}');
do $$
declare test_bucket text := replace(gen_random_uuid()::text,'-','') || replace(gen_random_uuid()::text,'-','');
begin
  for i in 1..5 loop
    if not public.winter_take_rate(test_bucket,'gift') then raise exception 'Allowed rate rejected'; end if;
  end loop;
  if public.winter_take_rate(test_bucket,'gift') then raise exception 'Rate limit bypass'; end if;
end;
$$;
reset role;
select set_config('winter.test_id',id::text,true) from public.winter_gifts where sender='RLS test' and created_at=now() limit 1;

set local role anon;
do $$
begin
  if not exists(select 1 from public.winter_ornaments where id=current_setting('winter.test_id')::uuid and shape='custom' and scene_x=0.25 and jsonb_array_length(outline)=4) then raise exception 'Missing public ornament'; end if;
  begin
    perform message from public.winter_gifts limit 1;
    raise exception 'Guest read succeeded';
  exception when insufficient_privilege then null;
  end;
  begin
    perform public.winter_add_gift('{"color":"ice","sender":"Anonymous test","song":"Test","message":"Test","url":""}');
    raise exception 'Guest write succeeded';
  exception when insufficient_privilege then null;
  end;
end;
$$;
reset role;

select set_config('request.jwt.claim.sub',gen_random_uuid()::text,true);
set local role authenticated;
do $$
begin
  if exists(select 1 from public.winter_gifts) then raise exception 'Non-owner read succeeded'; end if;
  update public.winter_gifts set favorite=true where id=current_setting('winter.test_id')::uuid;
  if found then raise exception 'Non-owner favorite succeeded'; end if;
  delete from public.winter_ornaments where id=current_setting('winter.test_id')::uuid;
  if found then raise exception 'Non-owner delete succeeded'; end if;
end;
$$;
reset role;

select set_config('request.jwt.claim.sub',current_setting('winter.test_owner'),true);
set local role authenticated;
do $$
begin
  if not exists(select 1 from public.winter_gifts where id=current_setting('winter.test_id')::uuid and message='Secret test') then raise exception 'Owner could not read'; end if;
  update public.winter_gifts set favorite=true where id=current_setting('winter.test_id')::uuid;
  if not found then raise exception 'Owner could not favorite'; end if;
  delete from public.winter_ornaments where id=current_setting('winter.test_id')::uuid;
  if not found then raise exception 'Owner could not delete'; end if;
  if exists(select 1 from public.winter_gifts where id=current_setting('winter.test_id')::uuid) then raise exception 'Cascade failed'; end if;
end;
$$;
rollback;
